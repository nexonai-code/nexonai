# unpruuf Business — Node-Mesh Architektur
## Implementierungs-Briefing für Claude Code

**Status:** Architektur-Spezifikation für den Business-Zweig von unpruuf — **implementiert**
(Stand v5, 2026-09-27; siehe Versionsgeschichte). Ersetzt/erweitert den aktuellen "optionaler Relay, TTL-begrenzt,
Opt-in"-Mechanismus aus `PRODUCT_CONTEXT.md` für alle Business-/Compliance-Deployments. Der
bestehende Android-P2P-Chat bleibt als eigenständiges Produkt unverändert bestehen (siehe
Abschnitt 0).

**Versionsgeschichte dieses Dokuments:**
- **v1 (Entwurf):** Aus einer Architektur-Diskussion mit Claude Chat. Modell: Sender legt
  Nachrichten auf den Nodes des **Empfängers** ab; Empfänger holt bei sich selbst ab.
- **v2:** Nach fachlicher Prüfung mit Claude Code umgedreht: Sender legt Nachrichten auf den
  **eigenen** Nodes ab; Empfänger holt beim **Absender** ab. Grund und Abwägung siehe
  Abschnitt 1. Zusätzlich: Schreibzugriff wird Owner-only (nie mit Kontakten geteilt), Abholen
  wird rein lesend (kein Delete-on-Fetch mehr, Aufräumen nur über TTL).
- **v3:** Alle in v2's Abschnitt 12 noch offenen Punkte entschieden — Rotation/TTL-Entkopplung
  bestätigt (mit Formel statt fixer Zahl), konkrete Default-Werte festgelegt, Reset gegenüber
  TTL-Cleanup präzise abgegrenzt, Ein-Node-Migrationslücke mit einer bewusst ehrlichen (nicht
  erfundenen) Antwort geschlossen. Keine offenen Punkte mehr — Abschnitt 12 dient seitdem als
  Entscheidungs-Log, nicht mehr als offene Liste.
- **Phase 1 gebaut:** `unpruuf/node-mesh-server/` existiert — Abschnitt 8's API (`PUT /deposit`,
  `GET /fetch`, `POST /fetchMany`), Owner-only-Auth, TTL-only Cleanup, vollständig getestet
  (`npm test`, 24/24). Android/iOS-Client, gebündeltes Tor-Prozessmanagement, Windows/Linux-
  Binary, Temp Node, Adressmigration, redundantes Multi-Node-Deposit waren noch **nicht** gebaut.
- **Phase 2a gebaut:** Android-Fundament-Bausteine — `IdentityManager.myNodeMeshRoutingSeed`/
  `nodeMeshPairSecret`/`nodeMeshEpoch`/`nodeMeshRoutingTag`/`nodeMeshToleranceEpochs`
  (Abschnitt 2/3's Krypto, echtes zweites eigenständiges Secret, nie mit `pairSecret`/Ratchet-Salt
  vermischt), `NodeMeshManager.kt` (eigener Node-Pool dieses Geräts, zwei getrennte
  String-Formate für Owner-Secret vs. Kontakt-Adressliste), `NodeMeshClient.kt` (HTTP-Client für
  `/deposit`/`/fetch`/`/fetchMany`), `Contact.nodeMesh`/`theirNodeMeshRoutingSeed`/
  `theirNodeAddresses` (`AppDatabase` v7 → v8).
- **Phase 2b gebaut (dieses Dokument, Status-Update):** Ende-zu-Ende funktionsfähig. Neuer
  Pairing-QR/-Screen (`NodeMeshPairing.kt`, dritter Chip in `QrPairScreen.kt`, eigenes,
  Edition-unabhängiges Format — kein Onion, kein Wire-Identity-Konzept, siehe Abschnitt 2), neue
  Settings-Sektion "Business Node-Mesh" zum Einrichten eigener Nodes, und die vollständige
  `P2PNetworkManager`-Anbindung: senden legt auf ALLEN eigenen erreichbaren Nodes ab
  (`depositToOwnNodes`, Abschnitt 5's Redundanz-Regel wörtlich umgesetzt), ein eigener,
  von `startRelayPoll` unabhängiger Poll-Loop (`pollNodeMeshOnce`) fragt bei jedem Node-Mesh-
  Kontakt dessen eigene Nodes über das per Formel berechnete Toleranzfenster ab (gebündelt via
  `fetchMany`, kein Delete-on-Fetch — Abschnitt 4). `resolveSender` wurde um einen
  Node-Mesh-Zweig erweitert, der den bestehenden Dedup-Mechanismus (`ingestPacket`) unverändert
  mitnutzt, indem der Routing-Tag an derselben Parameter-Position wie sonst die Wire-ID
  übergeben wird — kein neuer Ingest-Pfad nötig. Onion-spezifische Signale
  (`sendMainOnionUpdate`/`sendVerifiedOnionUpdate`) werden für Node-Mesh-Kontakte übersprungen;
  identitätsbasierte Signale (NEW_IDENTITY, Wechsel, Relay-Owner-Wechsel) gelten für Node-Mesh
  schon architektonisch nicht (kein Identity-/Relay-Pool-Konzept) und werden dafür nie ausgelöst.
  **Noch nicht gebaut:** Temp Node, Adressmigration (Abschnitt 6), redundante Multi-Node-Poll-
  Optimierung analog zu `fetchMany`-Batching über mehrere Kontakte hinweg (aktuell ein
  `fetchMany`-Aufruf pro Kontakt-Node, nicht gebündelt über Kontakte). Nicht build-verifiziert
  (kein Android-SDK hier) — auf Klammern-/Konsistenz-Balance geprüft.
- **Phase 3 (Teil 1+2) gebaut — v1.13:** Adressmigration (Abschnitt 6) und `fetchMany`-Bündelung
  über mehrere Kontakte hinweg. Adressmigration: `NodeMeshManager.migrateMyNode()` ersetzt lokal
  Adresse bei gleichbleibendem Owner-Secret (die Node-Identität hängt nicht von ihrer
  Netzwerkadresse ab); die Ankündigung an Kontakte (`sendNodeMigrationSignal`/
  `sendNodeMigrationSignalToAll`, neues `UNPRUUF_NODEMIGRATE_V1:`-Signal) läuft über die normale
  Zustellungs-Queue, die ohnehin jeden aktuell konfigurierten eigenen Node versucht und einzelne
  Fehlschläge toleriert — solange `migrateMyNode` VOR dem Versenden läuft, ist "nie über den sich
  ändernden Node selbst ankündigen" damit automatisch erfüllt, ganz ohne Sonderfall. Empfangsseite
  in `ingestPacketInner` ersetzt beim Kontakt gezielt die alte durch die neue Adresse (nicht die
  ganze Liste), dedupliziert, deckelt auf `NODE_POOL_MAX_SIZE`. Neue Settings-UI: pro eigenem Node
  ein "Migrate"-Button mit Inline-Eingabefeld. **Stand 25.10.2026 (Vor-Audit M4): nicht mehr gebündelt.** `pollNodeMeshOnce()` fragt je Kontakt und Node-Adresse einzeln, nur die Stunden seit dem letzten vollständigen Abruf (im Normalfall 2 bis 3 statt 26; nach einem App-Start oder einer Lücke das volle Fenster), mit zufällig gestaffeltem Start (bis 1,5 s). Seit 25.10.2026 hat jeder Kontakt außerdem einen eigenen SOCKS-Benutzernamen (Stream-Isolation, `Socks5.kt`, `TorIsolation.kt`) und einen eigenen Zeitgeber; Abrufe und Ablagen eines Kontakts laufen so auf eigenen Tor-Kreisen. Einheitengetestet gegen einen simulierten SOCKS-Server, noch nicht gegen echtes Tor geprüft. Der ursprüngliche Text zur Bündelung folgt als Geschichte. `fetchMany`-Bündelung: `pollNodeMeshOnce()` sammelt
  jetzt vor dem Abfragen alle Toleranzfenster-Tags ALLER Node-Mesh-Kontakte, gruppiert nach
  eindeutiger Node-**Adresse** (nicht mehr pro Kontakt), und macht genau einen `fetchMany`-Aufruf
  pro eindeutiger Adresse — exakt das bewährte `tagsByTarget`-Muster aus `pollRelayOnce()` (v1.09).
  Degradiert kostenlos auf "ein Aufruf pro Kontakt", falls Nodes wirklich pro Person eindeutig
  sind — reiner Gewinn, keine Regression.
- **Phase 3c gebaut — v1.14: Temp Node (Abschnitt 7).** Letztes Stück von Phase 3, damit
  NODE_MESH_SPEC.md vollständig umgesetzt. Siehe Abschnitt 7's neuer **[v4]**-Block für die
  Implementierungsentscheidungen im Detail (Pairing-Reihenfolge vereinfacht, ein einziger
  Zustands-Flag für Bestätigung+Wiederaufnahme, Dual-Deposit bis zur ersten Bestätigung).
  `node-mesh-server`: neuer `EPHEMERAL=1`/`--ephemeral`-Modus (`npm run start:tempnode`) —
  Identität und Message-Store beide nur im Prozessspeicher, nie auf Platte, jeder Neustart eine
  neue Node-Identität (`npm test` weiterhin 24/24). Android: `Contact.tempNodeAddress`/
  `tempNodeOwnerSecret`/`tempNodeActive`/`theirTempNodeAddress` (`AppDatabase` v8 → v9), neuer
  Chat-Screen-Dialog "Temp Node" (Scan/Paste desselben `unpruuf-node-owner:v1:...`-Formats wie
  Settings' Standard-Node-Setup, nur kontakt-gebunden), zwei neue Steuersignale
  (`UNPRUUF_TEMPNODE_V1:`/`UNPRUUF_TEMPNODE_OFF_V1`), `P2PNetworkManager.depositForNodeMesh`
  (routet Deposits durch den Temp Node, sobald aktiv, mit Fallback-Sicherheitsnetz auf den
  Standard-Pool bei einem einzelnen fehlgeschlagenen Versuch), `startTempNodeHeartbeat()`
  (2-Minuten-Intervall, 3 Fehlschläge in Folge lösen den automatischen Fallback aus),
  `theirTempNodeAddress` zusätzlich zur Standard-Adressliste in `pollNodeMeshOnce()` abgefragt.
  Nicht build-verifiziert (kein Android-SDK hier) — auf Klammern-/Konsistenz-Balance geprüft;
  `node-mesh-server`-Änderung echt getestet (`npm test`).
- **Windows-Binary gebaut — v1.14 (node-mesh-server).** Abschnitt 8's zuvor einzig noch offener
  Baustein. `node-mesh-server/build-exe.js` + neue `src/sea-entry.ts`/`src/sqliteNativeBinding.ts`
  — identische Node-SEA-Technik wie `unpruuf/server/`s `unpruuf-relay.exe` (siehe Abschnitt 8's
  neuer **[v4]**-Absatz und `node-mesh-server/EXE_BUILD.md` für den vollen Verifikationsstatus).
  Echt end-to-end auf Linux gebaut UND ausgeführt: `/health`/`/deposit`/`/fetch`/`/fetchMany` alle
  gegen die reale gebaute Binary getestet, `EPHEMERAL`-Modus nachweislich ohne Datei-Spuren.
  `npm test` weiterhin grün (jetzt 26/26, zwei neue Tests für den nativen-Binding-Override). Nicht
  verifiziert: ein echter Lauf auf echtem Windows (kein Windows-Rechner verfügbar). **Damit ist
  NODE_MESH_SPEC.md vollständig implementiert** — keine offenen Punkte aus Abschnitt 12/den
  Phase-Status-Notizen mehr übrig.

- **v5 (2026-09-27) — Betriebsreife.** Nach einer zweiten fachlichen Prüfung ("was fehlt für den
  echten Kundenbetrieb?") fünf Lücken geschlossen:
  1. **Tor ist jetzt eingebaut und Pflicht** (vorher: "Betreiber richtet selbst einen Hidden
     Service ein"). `node-mesh-server` lädt Tor, startet es selbst und veröffentlicht den Node per
     `ADD_ONION` — mit festem Schlüssel (Adresse ändert sich nie), Tor-eigenem Proof-of-Work-
     DoS-Schutz, automatischem Neustart und RAM-only-Schlüssel beim Temp Node. Abschnitt 8 [v5].
  2. **Profile statt freier Zahlen** (standard 6 h / high-security 1 h / offline-tolerant 24 h),
     Rotation als festes Protokoll-Konstante 1 h. Abschnitt 3 [v5].
  3. **Echter Bug behoben:** Der Android-Client ging fest von 6 h TTL beim Kontakt-Node aus —
     ein Node mit längerer TTL hätte Nachrichten gehalten, die der Client nie abfragt. Das
     Toleranzfenster deckt jetzt immer die maximal erlaubte TTL (24 h) ab. Abschnitt 3 [v5].
  4. **Android als Node-Host** (`relay-android`, Modus "Business Node") — Abschnitt 8's
     Plattformliste damit vollständig.
  5. **Windows/Linux/Docker-Pakete** mit Einrichtungsseite (Owner-QR) statt Kommandozeile; Slots
     1–3 für den versetzten Reset. Kundenseitige Betriebsdoku (Abschnitt 11): `NODE_MESH_BETRIEB.md`.

Alles hier Beschriebene ist neu gegenüber dem aktuellen Repo-Stand. Wo v1→v2→v3→v5 etwas geändert
hat, ist das mit **[v2]**/**[v3]**/**[v5]** markiert.

---

## 0. Scope-Abgrenzung — zwei Produkte, ein Krypto-Kern

| | Android P2P Chat (bestehend) | unpruuf Business / Node-Mesh (neu) |
|---|---|---|
| Transport | Direktes Tor-Rendezvous zwischen zwei Geräten, LAN-Fastpath | Ausschließlich über Node(s), nie direkt |
| Node | Optional, Opt-in-Fallback | **Mandatory** |
| Plattformen | Android | Windows, Linux, Android als Node-Host; Windows, Linux, Android, iOS als Client |
| iOS | Nicht unterstützt | Client-only (kann nie selbst Node sein) |

**Wichtig:** Double Ratchet (X25519-DH-Ratchet + HKDF-Kettenschlüssel + XChaCha20-Poly1305) und
die gesamte Nachrichten-Verschlüsselungslogik bleiben identisch und werden als gemeinsame
Bibliothek genutzt — nicht duplizieren. Was sich ändert, ist ausschließlich die
**Transport-/Routing-Schicht** darunter.

---

## 1. Grundprinzip [v2: Schreib-/Leserichtung umgedreht]

Zwei Kontakte kommunizieren nie direkt miteinander und lernen sich netzwerkseitig nie kennen.
Jeder betreibt seine eigene Node-Infrastruktur (**nie von NexonAI gehostet** — der Kunde
betreibt seine eigenen Nodes, das ist die rechtliche und vertrauenstechnische Grundlage).

**Jeder schreibt ausschließlich auf seinen EIGENEN Nodes. Jeder holt ausschließlich bei den
Nodes SEINER KONTAKTE ab.** Absender A legt eine Nachricht auf A's eigenen Nodes ab. Empfänger
B pollt A's Nodes und holt sie dort ab.

**Warum umgedreht gegenüber v1 (A legt bei B ab, B holt bei sich selbst ab):**

| | v1: Schreiben beim Empfänger | v2: Schreiben bei sich selbst |
|---|---|---|
| Sendezuverlässigkeit | Hängt vom Kontakt: ist SEIN Node gerade down, schlägt MEIN Senden fehl | Entkoppelt: mein Schreiben gelingt praktisch immer, da eigene Infrastruktur |
| Datenhoheit | Mein Node speichert fremde Inhalte, die andere ungefragt bei mir ablegen | Mein Node speichert ausschließlich, was ich selbst verfasst und freigegeben habe |
| Schreibzugriff auf meinen Node | Muss für jeden Kontakt offen/autorisiert sein (geteiltes Geheimnis) | Braucht **niemand außer mir selbst** — siehe Abschnitt 8 |
| "Nur halbe Konversation pro Node" | Gilt (nur Eingehendes) | Gilt genauso (nur Ausgehendes) — **keine neue Eigenschaft, bleibt in beiden Modellen erhalten** |

Die Richtungstrennung (Abschnitt 4) ist in beiden Modellen strukturell gleich stark. Der
eigentliche Gewinn von v2 ist die Verschiebung der Kontrolle: Sende-Zuverlässigkeit und
Datenhoheit liegen jetzt vollständig bei der schreibenden Seite selbst, und — am wichtigsten —
der Schreib-Zugriff auf einen Node muss nie mehr mit einem Kontakt geteilt werden (siehe
Abschnitt 8).

**Wichtige Einschränkung dieser Eigenschaft:** "Kein Node sieht beide Richtungen" gilt nur,
solange A's und B's Nodes von wirklich unabhängigen Parteien betrieben werden. Teilen sich zwei
Kunden denselben Node-Hosting-Anbieter, oder betreibt eine Firma die Nodes mehrerer ihrer
Mitarbeiter auf derselben Infrastruktur, sieht dieser eine Betreiber wieder beide Richtungen.
Das ist eine Annahme über die Deployment-Topologie, keine kryptographische Garantie — sollte in
der Kundenkommunikation so benannt werden, nicht als absolute Eigenschaft verkauft werden.
Ebenfalls wichtig: das ist eine Aussage über **Node-Kompromittierung** (was auf der Platte
steht), nicht über **Netzwerk-Traffic-Analyse** — ein globaler passiver Beobachter kann Timing
zwischen "A schreibt auf A's Node" und "B pollt A's Node kurz danach" weiterhin korrelieren, das
bleibt das allgemeine, ungelöste Tor-Problem (siehe `SECURITY_CLAIMS.md` Punkt 7).

Beim Pairing tauschen beide Kontakte aus:

- dass es sie gibt (Pairing-Geheimnis, wie bisher per QR-Code)
- **die eigenen** Node-Adressen (damit der Kontakt weiß, wo er später pollen muss)
- mit welchem Code sie die Nachrichten des jeweils anderen wiederfinden (Abhol-Code, s.
  Abschnitt 3)

**Keine User-ID (QR-Format v2, 2026-09-30).** Der Node-Mesh-Pairing-QR enthält nur noch
Nachrichtenschlüssel (`p`), Ratchet-Public-Key (`k`), Routing-Seed (`s`), Node-Adressen (`n`) und
Edition (`e`). Die frühere `u`-User-ID wurde von Routing und Krypto nie gelesen. Duplikaterkennung
beim erneuten Scannen läuft über den Nachrichtenschlüssel. v1-QR-Codes (mit `u`) werden weiterhin
gelesen, das Feld wird ignoriert.

**Eigene Schlüssel und eigene Nodes pro Kontakt (2026-10-01).** Bis 2026-09-30 waren
Nachrichtenschlüssel, Ratchet-Schlüssel, Routing-Seed und Node-Adressen pro Gerät global, zwei
Kontakte konnten durch QR-Vergleich feststellen, dass sie mit derselben Person sprechen. Seitdem
erzeugt jede Node-Mesh-Kopplung frisch: Nachrichtenschlüssel, X25519-Ratchet-Schlüsselpaar,
Routing-Seed — und wählt bis zu 3 eigene Nodes aus dem Pool, zuerst die am wenigsten benutzten,
verteilt über verschiedene Server. Gespeichert am Kontakt (`Contact.myPair*`,
`Contact.myNodeAddresses`, verschlüsselte DB), abgelegt wird nur noch auf die Nodes dieses
Kontakts. Solange der Pool genug Nodes hat (3 pro Kontakt), haben zwei Kontakte nichts
Gemeinsames mehr. Der angezeigte QR bleibt bis zum Scan gespeichert ("pending"), ein Bildschirm =
ein Kontakt.

**Viele Nodes pro Server.** `node-mesh-server` betreibt in einem Prozess mit einem Tor immer die
volle lizenzierte Zahl an Onion-Adressen (normal und höchstens **250**, keine Einstellung — jeder
Server sieht und lastet gleich). Die App scannt einen Owner-QR pro Server und holt die übrigen
Adressen über `GET /pool` (nur mit Owner-Secret), alle 6 h erneut — oder importiert die Node-Liste
als Datei (§15). Pool-Grenze in der App: 1000 eigene Nodes (vier volle Server). Messung siehe
`node-mesh-server/README.md`.

**Keine eigene Onion-Adresse auf dem Telefon (2026-10-01).** Im Node-Mesh-Pfad ist das Telefon
reiner Tor-Client: beim Ablegen weist es sich per Owner-Secret aus, beim Abholen per Routing-Tag.
Seit 2026-10-01 startet die App auch keinen eigenen Onion-Dienst mehr, solange kein Kontakt einen
braucht (Whistleblower-Edition nie; sonst nur bei mindestens einem direkten P2P-Kontakt oder wenn
der Nutzer ausdrücklich einen Onion-Pairing-QR öffnet).

---

## 2. Zwei Codes, zwei getrennte Aufgaben — nicht vermischen

Das ist der wichtigste Punkt der gesamten Spezifikation, unverändert gegenüber v1:

| | Abhol-Code (Routing-Tag) | Verschlüsselungs-Schlüssel (Ratchet) |
|---|---|---|
| Aufgabe | Sagt dem Node, welche Nachricht für wen bestimmt ist | Macht die Nachricht lesbar |
| Sichtbar für Node | Ja (das ist sein einziger Ablage-Schlüssel) | Nie |
| Rotiert | Ja, regelmäßig | Läuft unabhängig über den bestehenden Ratchet weiter |
| Bei Kompromittierung | Angreifer sieht nur, dass irgendein Umschlag abgeholt wurde — nichts über Inhalt oder Identität | Angreifer kann diese und künftige Nachrichten lesen (daher Ratchet, nicht statischer Schlüssel) |

**Implementierungsregel [v2 verschärft]:** `shared_pairing_secret` (für Routing) und der
Ratchet-Bootstrap-Seed werden als **zwei eigenständige Secrets beim Pairing etabliert**, nicht
als ein gemeinsames Wurzelsekret mit domain-separierten HKDF-`info`-Strings. Das bestehende
Android-P2P-Produkt macht Letzteres (`IdentityManager.pairSecret()` speist sowohl den Wire-Tag
als auch den Ratchet-Salt, nur mit unterschiedlichem Kontext-String) — für den Business-Zweig,
der als neue, eigenständige Spezifikation ohnehin frisch gebaut wird, ist die strengere Variante
vorzuziehen: kein gemeinsames Wurzelsekret, aus dem beides abgeleitet wird.

### Ableitung des Abhol-Codes

```
epoch_counter   = floor(unix_time / rotation_interval)
routing_tag     = HKDF(shared_pairing_secret, info = "routing" || epoch_counter)
```

- `shared_pairing_secret`: beim Pairing einmalig etabliertes, vom Ratchet-Seed unabhängiges
  Geheimnis.
- Epochen-Zähler statt roher Systemzeit verwenden — robuster gegen Uhr-Drift zwischen Geräten.
- `routing_tag` wird beim Ablegen UND beim Abholen verwendet, nie die Nachricht selbst.
- **[v2]** Der Routing-Tag ist jetzt zusätzlich das einzige Zugriffs-Credential für's Abholen
  (siehe Abschnitt 8) — er muss also aus einem Raum stammen, der gegen Brute-Force praktisch
  unangreifbar ist. HMAC-SHA256-Output erfüllt das (2²⁵⁶ Möglichkeiten); mit der bestehenden
  Tag-Zeichenklasse (`[A-Za-z0-9+/=_-]{1,64}`) aus dem heutigen Relay-Code weit übererfüllt.

---

## 3. Rotation ↔ TTL — entkoppelt, mit Formel [v3: bestätigt + präzisiert]

**v1-Vorschlag war:** `rotation_interval ≥ TTL` als harte Invariante, damit beim Poll nie mehr
als zwei Tags (aktuell + vorherig) geprüft werden müssen.

**Bestätigt für v3: Nicht koppeln.** Rotation und TTL bleiben unabhängig konfigurierbar, wie im
bestehenden Android-P2P-Produkt (`IdentityManager.currentHourBucket()` rotiert stündlich,
unabhängig vom Relay-TTL-Default von 6h). Der Grund für die v1-Kopplung — "sonst müssen zu viele
Tags pro Poll geprüft werden" — ist mit `POST /v1/fetchMany` (siehe `CHANGELOG.md`, v1.09)
hinfällig: beliebig viele Tags werden in **einem** Request gebündelt, der Kostenunterschied
zwischen 2 und 7 Tags ist marginal. Eine harte Kopplung würde dagegen einen echten Zielkonflikt
erzwingen: lange TTL (gut für Offline-Zustellung) würde zwangsläufig lange Rotation erzwingen
(schlechter für Unlinkability). Entkoppelt bekommt man beides gleichzeitig.

**Toleranzfenster-Formel [v3, neu — ersetzt den fixen "2 Tags"-Vorschlag aus v1]:** Statt eine
feste Anzahl Tags zu prüfen, wird das Toleranzfenster aus dem tatsächlichen Verhältnis von TTL
zu Rotation abgeleitet — dann ist es für JEDE Kombination aus `rotation_interval`/TTL korrekt,
egal welche Werte ein Deployment wählt:

```
tolerance_window_epochs = ceil(TTL / rotation_interval) + 1
```

Das `+1` deckt Geräte-Uhr-Drift zwischen den Peers ab (siehe Abschnitt 2's Epochen-Zähler-
Begründung). Der Poller fragt `epoch_counter` sowie die `tolerance_window_epochs` vorherigen
Epochen ab, alle in einem `fetchMany`-Request.

**Konkrete Defaults [v3, festgelegt]:**
- `rotation_interval`: **1 Stunde** — identischer Default wie das bestehende Android-Produkt,
  bewusst konsistent statt eine zweite, unbegründete Zahl einzuführen.
- `TTL`: **6 Stunden** — ebenfalls konsistent mit dem bestehenden Relay-Default
  (`server/src/config.ts`'s `DEFAULT_TTL_HOURS`).
- Daraus: `tolerance_window_epochs = ceil(6/1) + 1 = 7` Tags pro Poll-Runde (Default).
- Beide Werte bleiben **pro Kunden-Deployment konfigurierbar** (nicht hart codiert) —
  unterschiedliche Compliance-Anforderungen brauchen unterschiedliche Werte; die Formel bleibt
  dabei automatisch korrekt, ohne dass irgendwo ein zweiter, von Hand synchron zu haltender
  Toleranzwert gepflegt werden müsste.

**[v5] Umsetzung — Profile, feste Rotation, festes Client-Fenster:**

- `rotation_interval` ist eine **Protokoll-Konstante (1 h)**, kein Node-Parameter: Sender und
  Empfänger müssen denselben Wert benutzen, sonst stimmen die Tags nicht überein. Eine
  Konfiguration pro Node hätte Zustellung still gebrochen.
- TTL wird pro Node über ein **Profil** gewählt: `standard` 6 h, `high-security` 1 h,
  `offline-tolerant` 24 h (`node-mesh-server/src/profiles.ts`, identisch in `relay-android`).
  Obergrenze `MAX_TTL_HOURS = 24`.
- **Gefundener Bug (behoben):** Der Android-Client rechnete das Toleranzfenster mit fest 6 h TTL.
  Der Client kennt aber die TTL des *Kontakt*-Nodes nicht — bei einem 24-h-Node hätte er
  Nachrichten, die älter als 7 h sind, nie abgefragt. Jetzt rechnet der Client immer mit
  `MAX_TTL_HOURS`: `ceil(24/1) + 1 = 25` Epochen zurück plus die aktuelle = **26 Tags pro
  Kontakt**, weiterhin ein einziger `fetchMany`-Aufruf (Server-Cap 64). Damit ist *jedes* Profil
  abgedeckt, ohne dass der Client wissen muss, welches der Kontakt fährt. `profiles.test.ts` pinnt
  die Zahl serverseitig.

**Zu implementieren (Stand v3, durch v5 ersetzt):**
- Konfigurierbarer `rotation_interval` und `TTL`, unabhängig voneinander; Toleranzfenster wird
  **berechnet**, nie separat konfiguriert.
- Beim Poll alle Tags im berechneten Toleranzfenster in **einem** gebündelten Request abfragen
  (Node-Mesh-Äquivalent von `fetchMany`), Ergebnisse zusammenführen.

---

## 4. Nachrichtenfluss [v2: Richtung + Cleanup-Mechanismus geändert]

```
1. Sender verschlüsselt Nachricht mit aktuellem Ratchet-Schlüssel.
2. Sender berechnet routing_tag für den aktuellen epoch_counter.
3. Sender legt Ciphertext + TTL bei ALLEN erreichbaren EIGENEN Nodes ab
   (bis zu 3, siehe Abschnitt 5) — Owner-only-Schreibzugriff, siehe Abschnitt 8.
4. Empfänger pollt periodisch (oder erhält Push-Trigger) bei den Nodes SEINES KONTAKTS,
   fragt routing_tag(aktuell) und alle Tags im Toleranzfenster ab (Abschnitt 3), gebündelt
   in einem Request.
5. Empfänger dedupliziert über Message-ID (nicht über Tag — mehrere eigene Nodes des Kontakts
   können dieselbe Nachricht halten).
6. **[v2] Kein Delete-on-Fetch mehr.** Abholen ist rein lesend — der Fetch-Endpunkt braucht
   dafür keine Schreib-/Löschrechte, die an den Kontakt vergeben werden müssten (siehe
   Abschnitt 8, Begründung).
7. Läuft die TTL ab: Node löscht automatisch, unabhängig davon, ob/wie oft die Nachricht
   zwischendurch gelesen wurde.
```

**Trade-off durch Punkt 6 [v2]:** Eine bereits gelesene Nachricht bleibt bis zum TTL-Ablauf auf
dem Node liegen (kein sofortiges Aufräumen nach erfolgreicher Zustellung). Dafür bekommt der
Kontakt beim Abholen nie mehr als Lesezugriff — niemand außer dem Node-Besitzer selbst kann je
etwas von diesem Node löschen. Bei kurzer, deployment-üblicher TTL (Stunden, nicht Tage) ist der
zusätzliche Speicherbedarf gering und der Sicherheitsgewinn (kein Fremd-Löschrecht) wiegt das
klar auf.

**Wichtig — kein Message-ID-Leak an den Node** (unverändert aus v1): Die Message-ID selbst muss
Teil des verschlüsselten Envelopes sein, nicht ein Klartext-Feld auf Node-Ebene, sonst kann der
Node über wiederholte IDs Muster über Zeit korrelieren. Dedup passiert client-seitig nach
Entschlüsselung.

**Richtungstrennung** (aus v1 übernommen, jetzt spiegelverkehrt — siehe Abschnitt 1's Tabelle):
Da A ausschließlich auf A's eigenen Nodes ablegt und B ausschließlich auf B's eigenen, hält kein
einziger Node je beide Richtungen eines Gesprächs. A's eigene Nodes sehen nur A's ausgehenden
Verkehr an alle Kontakte, nie eingehende Antworten. In Kombination mit der TTL-basierten
Löschung nach Abschnitt 4 hält ein Node zu keinem Zeitpunkt mehr als Fragmente einer einzigen
Richtung — nie ein vollständiges Gespräch. Eine vollständige Kompromittierung eines einzelnen
Knotens liefert einem Angreifer daher nie Frage-Antwort-Muster (mit der Einschränkung aus
Abschnitt 1 zur Betreiber-Unabhängigkeit), sondern höchstens Timing/Volumen einer Richtung.

---

## 5. Redundanz — bis zu 3 eigene Nodes, versetzter Reset [v3: Reset-Umfang präzisiert]

- Jeder Kontakt kann bis zu 3 **eigene** Nodes betreiben (Windows, Linux oder Android-Gerät).
  **Empfehlung [v3, neu]:** mindestens **2** Nodes für jedes Deployment, dem Migrationsfähigkeit
  wichtig ist — Begründung siehe Abschnitt 6. Ein einzelner Node bleibt funktional gültig, verliert
  dabei aber die Fähigkeit, die eigene Adresse später zu wechseln, ohne Kontakte manuell neu zu
  pairen.
- Sender legt Nachrichten bei **allen erreichbaren eigenen** Nodes ab (nicht nur primär +
  Failover) — überlebt eine Nachricht auch, wenn einer der eigenen drei Nodes ausfällt, nachdem
  geschrieben, aber bevor der Kontakt abgeholt hat.
- **Reset-Definition [v3, präzisiert — löst die in v2 offene Überschneidung mit TTL-Cleanup]:**
  Reset ist **ausschließlich** periodische Verbindungs-/Socket-Hygiene — abgelaufene Tor-Circuits
  und offene Handles zurücksetzen, damit ein lange laufender Prozess nicht langsam
  Ressourcen-Lecks anhäuft. **Reset rührt nie Nachrichtendaten an** (das ist vollständig
  TTL-Cleanups Aufgabe, siehe Abschnitt 8 — keine Überschneidung mehr) **und nie
  Rate-Limit-Zähler** (die laufen als Token-Bucket, der sich kontinuierlich selbst erneuert und
  keinen diskreten Reset braucht). Diese enge Definition erklärt auch, warum der Versatz
  überhaupt nötig ist: ein Verbindungs-Rebuild verursacht kurz eine kleine Erreichbarkeits-Delle
  — bei gleichzeitigem Reset aller drei Nodes wären kurzzeitig alle drei betroffen, versetzt bleibt
  immer mindestens einer ungestört. (Zähler-Bereinigung allein bräuchte diesen Versatz gar nicht
  — sie ist instantan und unterbricht nichts.)
  - **Ändert nie die Node-Adresse.**
  - Die Nodes eines Kontakts resetten **zeitlich versetzt**, nie gleichzeitig.
  - Versatz-Implementierung bei 3 Nodes: z. B. Node 1 bei Minute 0, Node 2 bei Minute 20, Node 3
    bei Minute 40 eines konfigurierbaren Zyklus (Default 24h, s. u.). Bei 2 Nodes entsprechend
    Minute 0 / Minute 30 pro 24h-Zyklus.

**[v5] Umsetzung:** Jeder Node bekommt einen **Slot 1/2/3** (`NODE_SLOT`, in `relay-android`
als Auswahl in der App). Der Reset läuft bei Minute 0/20/40 eines 24-h-Zyklus, **an der Uhrzeit
(UTC) ausgerichtet**, nicht am Prozessstart — sonst würden drei Nodes, die zu beliebigen Zeiten
gestartet wurden, nicht zuverlässig versetzt laufen. Inhalt des Resets auf dem PC-Node: offene
Leerlauf-HTTP-Sockets schließen, prüfen, ob der Onion-Service noch bei Tor registriert ist (sonst
mit demselben Schlüssel neu anmelden), SQLite-WAL zurückschreiben. Auf Android: dieselbe
Onion-Prüfung.

**Default [v3, festgelegt]:** Reset-Intervall 24h, konfigurierbar pro Deployment. Da Reset jetzt
nachweislich nie Nachrichtendaten anfasst, ist die in v2 befürchtete Kollision mit einem laufenden
Zustellfenster strukturell ausgeschlossen — keine weitere Abstimmung mit TTL/Rotation nötig.

---

## 6. Adressmigration eines eigenen Nodes [v2: vereinfacht sich durch die neue Richtung]

Ändert einer der drei eigenen Nodes seine Adresse (z. B. Server-Umzug), gilt:

1. **Nie über den wechselnden Node selbst kommunizieren** — Henne-Ei-Problem, der Kontakt weiß
   ja noch nicht, wo er suchen soll.
2. Migrations-Nachricht ("meine Node-X-Adresse ist jetzt Y") wird als ganz normale,
   verschlüsselte Nachricht über die **eigenen verbleibenden funktionierenden Nodes** (die
   anderen zwei) abgelegt — läuft durch denselben Mechanismus wie jede reguläre Nachricht, kein
   Sondercode nötig. **[v2]** Läuft jetzt sogar noch natürlicher als in v1: es ist buchstäblich
   eine normale ausgehende Nachricht (ich schreibe sie auf meine eigenen, noch funktionierenden
   Nodes, mein Kontakt pollt die ja sowieso schon).
3. Alte Adresse bleibt für ein Übergangsfenster (empfohlen: mindestens eine TTL-Länge) parallel
   aktiv, falls der Kontakt offline war und die Migrationsnachricht erst später abholt.
4. **Nie alle drei eigenen Nodes gleichzeitig migrieren** — mindestens einer muss während der
   gesamten Migration erreichbar bleiben, sonst gibt es keinen Kanal mehr, über den die neue
   Adresse zugestellt werden könnte.

**Ein-Node-Deployments [v3, entschieden]:** Ein Redirect-Stub am alten Endpunkt wurde geprüft und
bewusst verworfen — er würde voraussetzen, dass am alten Standort noch etwas laufen gelassen
werden kann, was bei den realistischen Migrationsgründen (Hardware-Tausch, ISP-Kündigung,
Hoster-Wechsel) oft genau die Situation ist, die nicht mehr gegeben ist. Ein unzuverlässiger
Mechanismus, der manchmal funktioniert, ist schlechter als gar keiner, weil er falsche Sicherheit
suggeriert. Stattdessen, ehrlich dokumentiert:

- Migrationsfähigkeit **ohne Kontakteingriff** braucht mindestens 2 Nodes (siehe Abschnitt 5's
  Empfehlung). Das ist der reguläre, empfohlene Weg.
- Bei einer **bewussten** Ein-Node-Installation gibt es keinen automatischen Migrationspfad —
  das ist eine akzeptierte, dokumentierte Einschränkung, keine zu lösende Lücke. Verliert der
  einzige Node seine Adresse, muss der Besitzer die neue Adresse **außerhalb des Systems**
  mitteilen (z. B. ein neuer Pairing-QR-Code, analog zum Erst-Pairing) — Kontakte pairen dann
  gezielt neu, statt automatisch zu migrieren.
- Diese Einschränkung gehört in die Kunden-facing Dokumentation (Abschnitt 11), nicht nur hierher
  — ein Ein-Node-Kunde muss das VOR dem Deployment wissen, nicht erst beim ersten Adresswechsel
  entdecken.

---

## 7. Temp Node (Premium-Feature) [v2: Bootstrap-Problem löst sich von selbst]

Für Ausnahmefälle: im laufenden Chat einen temporären eigenen Node auf beliebiger eigener
Hardware aktivieren (Zweithandy, Tablet, Laptop) — ausschließlich für diesen einen Chat, als
zusätzlicher eigener Schreibziel-Node für Nachrichten an genau diesen Kontakt.

**Ablauf:**
1. Nutzer wählt in der Chat-Ansicht "Temp Node aktivieren".
2. App generiert Pairing-Code für den Temp Node, zeigt QR-Code.
3. Zweitgerät (Node-Tool) scannt den Code, registriert sich als zusätzlicher eigener Temp Node,
   gültig nur für Nachrichten an diesen einen Kontakt.
4. Ankündigung ("ich habe jetzt einen Temp Node unter Adresse Z, nutze ihn für diesen Chat")
   wird als ganz normale, verschlüsselte Nachricht über die **bestehenden Standard-Nodes**
   abgelegt.
5. **[v2, gelöst]** Das in v1 offene Henne-Ei-Problem ("läuft die Bestätigung über den noch
   unbewiesenen Temp Node, oder über die Standard-Nodes?") entfällt durch die neue Richtung von
   selbst: die Ankündigung ist eine ganz normale ausgehende Nachricht auf den eigenen
   Standard-Nodes, die der Kontakt ohnehin schon pollt — der Kontakt braucht keinerlei vorherigen
   Kontakt zum Temp Node, um die Ankündigung zu bekommen.
6. Ab Bestätigung durch den Kontakt (z. B. erste erfolgreiche eigene Nachricht über den Temp
   Node in diese Richtung): Standard-Nodes für diesen einen Chat pausieren, nicht parallel
   weiterlaufen lassen. Ausschließlich der Temp Node trägt ab jetzt den ausgehenden Verkehr
   dieses einen Chats.
7. **Heartbeat/Timeout, nicht nur "Tool geschlossen":** Beide Seiten pingen den Temp Node in
   festem Intervall. Bleiben N aufeinanderfolgende Heartbeats aus (Timeout konfigurierbar,
   Vorschlag: 3 × Heartbeat-Intervall), fällt der Chat automatisch auf die drei Standard-Nodes
   zurück — nicht erst beim expliziten Schließen der Temp-Node-App.
8. Beim regulären Schließen des Temp-Node-Tools: sauberer Übergang zurück auf Standard-Nodes,
   Temp-Node-Session-Daten werden gelöscht (RAM-only, wie der reguläre Node-Speicher auch).

**[v4: Implementierungsentscheidungen — gebaut]**

- **Pairing-Reihenfolge vereinfacht.** Schritt 2 oben beschreibt "Telefon zeigt QR zuerst, Node-
  Tool scannt". Gebaut wurde stattdessen die exakt umgekehrte, aber funktional gleichwertige
  Reihenfolge: das Node-Tool (`node-mesh-server` mit `EPHEMERAL=1`) generiert beim Start ganz
  normal seine eigene Identität (wie ein Standard-Node auch) und druckt den fertigen
  `unpruuf-node-owner:v1:<address>:<secret>`-String; das Telefon scannt/pastet genau diesen
  String im neuen Chat-Screen-Dialog "Temp Node" — dasselbe Format, dieselbe
  `NodeMeshManager.parseOwnerConnectionString`-Funktion, die auch Settings' Standard-Node-Setup
  schon nutzt, nur hier kontakt-gebunden statt global gespeichert. Grund: das Node-Tool ist eine
  Kommandozeilen-/Docker-Binary ohne Kamera — eine zweite, für diese eine Funktion neu gebaute
  QR-Scan-Fähigkeit dort wäre erheblicher Zusatzaufwand für keinen funktionalen Gewinn, da beide
  Richtungen exakt dieselben zwei Informationen (Adresse + Secret) austauschen müssen.
- **Ein einziger Zustands-Flag statt getrennter Bestätigungs-/Wiederaufnahme-Logik.**
  `Contact.tempNodeActive` wird durch GENAU EINE Übergangsregel gesteuert: jeder erfolgreiche
  Kontakt zum Temp Node — ob ein echtes Deposit (Erstbestätigung, §7 Schritt 6) oder ein
  erfolgreicher Heartbeat (Wiederaufnahme nach einem automatischen Fallback, §7 Schritt 7) —
  setzt ihn auf `true`; nur `TEMP_NODE_HEARTBEAT_FAILURE_THRESHOLD` (3) aufeinanderfolgende
  Heartbeat-Fehlschläge setzen ihn zurück auf `false`. Die Spezifikation nennt "erste
  erfolgreiche Nachricht" ausdrücklich als Beispiel ("z. B."), nicht als exklusiven Mechanismus —
  einen erfolgreichen Heartbeat für den Wiederaufnahme-Fall gleichwertig zu behandeln ist damit
  eine bewusste, spezifikationskonforme Lesart, kein Sonderfall.
- **Solange nicht bestätigt: Dual-Deposit statt reinem Warten.** Zwischen Registrierung und
  erster Bestätigung sendet `P2PNetworkManager.depositForNodeMesh` jede Nachricht sowohl an den
  Temp Node als auch an den Standard-Pool — sonst gäbe es nie ein "erstes erfolgreiches Deposit",
  das die Bestätigung auslösen könnte. Die Ankündigungs-Nachricht selbst (Schritt 4) geht dadurch
  im Prinzip ebenfalls an beide, nicht nur an die Standard-Nodes wie im Wortlaut oben — harmlos,
  da Mehrfachzustellung über den bestehenden `ingestPacket`-Dedup ohnehin schon abgefangen wird,
  und der eigentliche Zweck von Schritt 4 (nie über den noch unbewiesenen Node bootstrappen) durch
  das gleichzeitige Standard-Node-Deposit weiterhin erfüllt ist.
- **Heartbeat-Fehlerzähler ist reiner Prozessspeicher**, nicht in `Contact` persistiert — nur der
  Heartbeat-Loop selbst braucht die Zwischenzahl zwischen 1 und dem Schwellenwert, kein anderer
  Codepfad liest sie.

---

## 8. Node-Server — Anforderungen an die Implementierung [v3: implementierungsreif]

**Plattformen:** Windows-Binary, Linux-Binary/Docker, Android-APK. Gleiches Wire-Format
über alle drei (Grundprinzip aus dem bestehenden Relay-Pool-Feature beibehalten — byte-für-byte
kompatibel).

**Implementierungs-Basis [v3, neu]:** Der bestehende Node-Code (`unpruuf/server/` für Node.js,
`unpruuf/relay-android/` für Kotlin) ist der richtige Ausgangspunkt, nicht ein Neubau von Null.
TTL-Sweep, `fetchMany`-Batching/Long-Poll (siehe unten), Tag-Validierung und das Wire-Format sind
bereits gebaut, getestet und funktionieren identisch auf beiden Plattformen. Was sich ändert, ist
gezielt: (a) `/deposit`'s Auth-Modell (Owner-Secret statt geteiltes Bearer-Token), (b) `/fetch`
verliert seine Lösch-Wirkung.

**[v4, gebaut] Windows-Binary.** `node-mesh-server/build-exe.js` erzeugt eine eigenständige
`unpruuf-node-mesh.exe`, die kein separat installiertes Node.js zum AUSFÜHREN braucht (nur einmal
zum Bauen) — exakt dieselbe Node-"Single Executable Application"-Technik, die `unpruuf/server/`
schon für `unpruuf-relay.exe` nutzt (Bündelung via `esbuild`, `postject`-Injektion in eine Kopie
der echten Node-Binary, `better-sqlite3`s natives Addon als Sibling-Datei neben der `.exe`, da SEA
nur JavaScript einbetten kann). Siehe `node-mesh-server/EXE_BUILD.md` für die volle Erklärung und
den Verifikationsstatus — end-to-end auf Linux gebaut UND ausgeführt (nicht nur gebaut): `/health`,
`/deposit`, `/fetch`, `/fetchMany` antworteten korrekt gegen die echte gebaute Binary, `EPHEMERAL`-
Modus hinterließ nachweislich keine Datei. Nicht verifiziert: ein echter Lauf auf echtem Windows
(kein Windows-Rechner zum Bauen/Testen verfügbar) — der Mechanismus selbst ist Node/OS-agnostisch
und wurde real durchlaufen, nur die Windows-spezifische Ausführung des fertigen Binaries nicht.

**[v5, gebaut] Tor ist eingebaut und Pflicht.** Vorher musste der Betreiber selbst einen Hidden
Service vor den Node setzen — für die Zielgruppe (Compliance-Abteilungen, keine Tor-Admins)
unrealistisch, und ohne Onion wäre "Node sieht nie eine Absender-IP" nur eine Regel statt einer
Struktureigenschaft. Jetzt (`node-mesh-server/src/tor/`):

- Tor Expert Bundle (gepinnt, 15.0.19 / Tor 0.4.9.11) wird beim ersten Start geladen; Tor läuft
  als reiner Onion-Host (`SocksPort 0`), Control-Port auf freiem Port, Cookie-Auth,
  `__OwningControllerProcess` (Tor beendet sich selbst, wenn der Node-Prozess stirbt).
- Veröffentlichung per `ADD_ONION` über den Control-Port, **nie** per `HiddenServiceDir`: der
  Schlüssel wird im Node-Identity-File (Modus 600) gespeichert und bei jedem Start wiederverwendet
  → Adresse bleibt immer gleich. Temp Node: Schlüssel nur im Arbeitsspeicher.
- **Proof-of-Work-DoS-Schutz** von Tor (`PoWDefensesEnabled=1`, Rate 250/Burst 2500) ist immer
  an. Das ist die richtige Ebene für Flood-Schutz: Die Lese-Endpunkte sind absichtlich ohne Auth
  (Tag = Credential), und einen Verbindungs-Flood kann nur Tor abwehren, bevor er den Node
  erreicht. Die App-seitige Rate-Limitierung (Token-Bucket) bleibt als zweite Schicht.
- Selbstheilung: Tor-Absturz oder Control-Verbindungsverlust → Neustart mit Backoff (2 s … 60 s),
  gleicher Schlüssel, gleiche Adresse. Real getestet mit `kill -9`.
- Einrichtungsseite auf eigenem Loopback-Port (nie Teil des Onion-Port-Mappings), mit
  `Host`-Header-Prüfung gegen DNS-Rebinding — zeigt Owner-QR zum Scannen in die eigene App.

**[v5, gebaut] Android als Node-Host.** `relay-android` hat einen Modus "Business Node": gleicher
HTTP-Vertrag wie der PC-Node (per JVM-Vertragstest über echtes HTTP geprüft), Owner-only-Deposit,
reines Lesen, TTL-only-Löschen, Profile und Slots, **eigener Onion-Schlüssel pro Modus** (ein
Gerät, das vom Relay zum Node wechselt, bekommt eine neue Adresse — Relay-Kontakte landen nie
versehentlich auf einem Node). **Einschränkung, ehrlich:** Die Android-Tor-Bibliothek (jtorctl)
kann `ADD_ONION` keine PoW-Parameter mitgeben, und ob `tor-android` das PoW-Modul enthält, ist
nicht belegt — Android-Nodes haben deshalb nur die App-seitige Rate-Limitierung, keinen
Tor-PoW. Für Deployments, bei denen Flood-Schutz zählt: PC/Server-Node bevorzugen.

**[v5] Per-Tag-Cap durchgerechnet (§9-Checkpunkt):** Die TTL spielt für den Per-Tag-Cap keine
Rolle — der Routing-Tag rotiert stündlich, ein Tag sammelt also immer nur *eine Stunde* ausgehenden
Verkehr *eines* Kontakts, egal wie lang die TTL ist. 1500 deckt einen vollen 5-MB-Anhang (~1311
Chunks) innerhalb einer Stunde ab → Wert unverändert korrekt.

**API-Oberfläche:**

- `PUT /deposit` — `{ routing_tag, ciphertext, ttl }` → legt Nachricht ab.
  **Owner-only: verlangt ein lokales Owner-Secret, das NIE an Kontakte weitergegeben wird**
  (generiert beim Ersteinrichten des Node-Tools, bleibt zwischen dem Node und der/den eigenen
  App-Instanz(en) desselben Besitzers). Kein Kontakt, kein Fremder kann je auf diesen Endpunkt
  schreiben — fundamental kleinere Angriffsfläche als ein für alle Kontakte offener
  Schreibzugriff, egal ob mit oder ohne geteiltem Token.
- `GET /fetch?tag=<routing_tag>` → gibt alle unter diesem Tag liegenden Nachrichten zurück.
  **Rein lesend, löscht nichts.** Kein Auth-Token nötig — der `routing_tag` selbst ist bereits
  das Zugriffs-Credential, da er aus dem Pairing-Geheimnis abgeleitet und praktisch nicht
  erratbar ist (siehe Abschnitt 2). Ein Bearer-Token wäre hier redundant.
- `POST /fetchMany` — `{ "tags": [...], "waitMs"?: number }` → `{ "blobs": { "<tag>": ["<base64
  ciphertext>", ...], ... } }`. **[v3, präzisiert]** Identisches Wire-Format zum bestehenden
  `POST /v1/fetchMany` (`server/src/routes/relay.ts`, v1.09) — gleiche Feldnamen, gleiches
  Long-Poll-Verhalten (`waitMs`, resolved sobald irgendeiner der angefragten Tags eine neue
  Nachricht hat oder das Timeout erreicht ist). Ein Request für alle Tags im per Formel
  berechneten Toleranzfenster (Abschnitt 3) statt einem Request pro Tag.
- Interner Cleanup-Job: entfernt abgelaufene TTL-Einträge, unabhängig vom Reset-Zyklus — **der
  einzige Löschmechanismus, seit Fetch nicht mehr löscht** (Abschnitt 5 hat den Reset-Umfang klar
  davon abgegrenzt).
- Reset-Endpoint (intern getriggert, nicht von außen aufrufbar, Owner-only wie `/deposit`):
  reine Verbindungs-/Socket-Hygiene wie in Abschnitt 5 präzisiert, rührt nie Nachrichtendaten an.

**Speicher-Dimensionierung [v3, neu — Konsequenz aus "kein Delete-on-Fetch"]:** Ohne
Delete-on-Fetch bleibt eine bereits gelesene Nachricht bis TTL-Ablauf liegen, statt sofort Platz
freizugeben — ein Tag kann daher innerhalb einer TTL-Periode mehr Einträge ansammeln als im
bestehenden Relay-Modell. Der bestehende Per-Tag-Cap (`MAX_BLOBS_PER_TAG`, aktuell 1500 im
Node-Relay) ist als Ausgangswert weiterhin sinnvoll, sollte aber im Node-Mesh-Kontext gegen die
gewählten TTL/Rotation-Defaults durchgerechnet werden, statt unverändert übernommen zu werden.

**Der Node darf strukturell nie folgendes speichern oder loggen:**
- Sender-IP über die Zustellung der einzelnen Nachricht hinaus
- Message-Metadaten außerhalb von `routing_tag` + `ttl` + Ciphertext
- Irgendeine Zuordnung "dieser routing_tag gehört zu Kontakt X" — der Node kennt nur den
  Tag, nie die Identität dahinter

**Rate-Limiting/Missbrauchsschutz [v2, Risiko deutlich reduziert]:** Da `/deposit` jetzt
Owner-only ist, entfällt das v1-Risiko "jeder mit der Adresse kann Spam ablegen" komplett — kein
Fremder kann überhaupt schreiben. Verbleibendes, kleineres Risiko: `/fetch`/`/fetchMany` mit
massenhaft geratenen Tags zu bombardieren, um per Brute-Force gültige Tags zu finden — bei
HMAC-SHA256-Tag-Länge praktisch aussichtslos, aber ein moderates Rate-Limit auf die
Lese-Endpunkte kostet nichts und ist als Tiefenverteidigung sinnvoll.

---

## 9. Sicherheitsanforderungen — explizite Checkliste [v3, final]

- [ ] Ratchet-Schlüssel und Routing-Tag werden aus **zwei eigenständigen Secrets** abgeleitet
      (siehe Abschnitt 2), nie einem gemeinsamen Wurzelsekret.
- [ ] Node speichert nie eine Zuordnung Tag → Identität.
- [ ] Message-ID (für Dedup) ist Teil des verschlüsselten Payloads, nie Klartext-Feld.
- [ ] Rotation des Routing-Tags läuft unabhängig von TTL und von der Ratchet-Rotation
      (Abschnitt 3 — bewusst NICHT gekoppelt; Toleranzfenster wird stattdessen per Formel
      berechnet).
- [ ] `/deposit` akzeptiert ausschließlich mit dem lokalen Owner-Secret authentifizierte
      Schreibvorgänge — nie ein mit Kontakten geteiltes Token, nie offen ohne Auth.
- [ ] `/fetch`/`/fetchMany` sind rein lesend — kein Delete-on-Fetch, keine Löschrechte werden je
      an einen Kontakt vergeben. Aufräumen ausschließlich über TTL-Ablauf.
- [ ] Reset rührt ausschließlich Verbindungs-/Socket-Zustand an — nie Nachrichtendaten, nie
      Rate-Limit-Zähler, nie eine Node-Adresse (Abschnitt 5).
- [ ] Adressmigration läuft nie über den migrierenden Node selbst; Ein-Node-Deployments haben
      dokumentiert **keinen** automatischen Migrationspfad (Abschnitt 6) — das steht auch in der
      kundenseitigen Dokumentation, nicht nur hier.
- [ ] Temp Node pausiert Standard-Nodes für den betroffenen Chat vollständig, kein
      Parallelbetrieb.
- [ ] Temp Node fällt bei Heartbeat-Timeout automatisch zurück, nicht nur bei explizitem
      Schließen.
- [ ] Verifizieren, dass die Ablage-Logik strikt "nur auf eigenen Nodes" einhält — jede
      Implementierung, die eingehende Nachrichten zusätzlich irgendwo spiegelt (z. B. als
      Sync-Mechanismus für Mehrgeräte-Nutzung), hebelt die Richtungstrennung aus Abschnitt 4 aus
      und muss über einen separaten, klar gekennzeichneten Pfad laufen, nie über den
      Standard-Zustellpfad.
- [ ] Per-Tag-Speicher-Cap (Abschnitt 8) gegen die gewählten TTL/Rotation-Defaults durchgerechnet,
      nicht unverändert aus dem bestehenden Relay übernommen.

---

**[v5] Stand der Checkliste:** Owner-only-Deposit, reines Lesen, TTL-only-Löschen, "Tag kann TTL
nur verkürzen" — per HTTP-Test auf beiden Node-Plattformen geprüft (`node-mesh-server` `npm test`,
`relay-android` `NodeMeshHttpServerTest`). Reset rührt keine Nachrichten/Adresse an — per Code
und Lauf geprüft (Adresse nach Neustart und nach Tor-Absturz identisch). Per-Tag-Cap —
durchgerechnet (Abschnitt 8 [v5]). Temp-Node-Pause — Code-Review von
`P2PNetworkManager.depositForNodeMesh`: im aktiven Zustand geht ausgehender Verkehr nur an den Temp
Node; der Standard-Pool dient ausschließlich als Rettungsnetz für eine *einzelne* fehlgeschlagene
Nachricht, bis der Heartbeat den Zustand zurücksetzt. Das ist spezifikationskonform, weil jede
Seite nur ihren *eigenen* ausgehenden Verkehr steuert — eine "beidseitige" Pause gibt es im
v2-Modell nicht.

## 10. Bewusst nicht Teil dieser Spezifikation

- Kein Gruppenchat (weiterhin Architekturentscheidung, siehe bestehendes Produktwissen).
- Kein zentral von NexonAI betriebener Node — widerspricht dem Grundprinzip dieses gesamten
  Dokuments.
- Kein Ersatz für das bestehende Android-P2P-Produkt — Node-Mesh ist der Business-Zweig,
  keine Migration des bisherigen Consumer-Produkts.

---

## 11. Auswirkung auf bestehende Dokumentation

Die vier "Was X wirklich bedeutet"-Kapitel (`Contact`, `Sending`, `Message`, `Node`) beschreiben
aktuell das Direct-P2P-Modell mit optionalem Relay. Für den Business-Zweig braucht es eine
eigene, an dieses Dokument angelehnte Fassung — nicht die bestehenden vier Kapitel überschreiben
(die gelten weiter für das Android-P2P-Produkt), sondern als eigenständige Business-Variante
ergänzen, sobald implementiert. Muss explizit die Ein-Node-Einschränkung aus Abschnitt 6 enthalten
— ein Kunde, der sich für ein Ein-Node-Deployment entscheidet, muss das vor dem Kauf/Deployment
wissen, nicht erst beim ersten Adresswechsel entdecken.

**[v5] Erledigt:** `NODE_MESH_BETRIEB.md` — kundenseitige Betriebsanleitung (Deutsch), inkl.
Ein-Node-Einschränkung, Profilwahl, Slots, Temp Node und der Android-PoW-Einschränkung.

---

## 12. Entscheidungs-Log — alle Punkte final geklärt [v3]

Kein offener Punkt mehr vor Implementierungsstart. Zur Nachvollziehbarkeit, was wann warum
entschieden wurde:

| Punkt | Entscheidung | Abschnitt |
|---|---|---|
| Schreib-/Leserichtung | Jeder schreibt auf eigene Nodes, holt bei Kontakten ab (v1 war umgekehrt) | 1 |
| Routing-/Ratchet-Secrets | Zwei eigenständige Secrets ab Pairing, kein gemeinsames Wurzelsekret | 2 |
| Rotation ↔ TTL | Bewusst entkoppelt; Toleranzfenster per Formel `ceil(TTL/rotation)+1` berechnet | 3 |
| Default `rotation_interval` | 1 Stunde (konsistent mit bestehendem Android-Produkt) | 3 |
| Default `TTL` | 6 Stunden (konsistent mit bestehendem Relay-Default) | 3 |
| Deposit-Endpunkt | Owner-only, lokales Secret, nie mit Kontakten geteilt | 8 |
| Fetch-Endpunkt | Rein lesend, kein Delete-on-Fetch, Tag selbst ist das Zugriffs-Credential | 4, 8 |
| Aufräumen | Ausschließlich TTL-Ablauf | 4, 8 |
| Reset-Umfang | Nur Verbindungs-/Socket-Hygiene; nie Nachrichten, nie Rate-Limit-Zähler, nie Adresse | 5 |
| Default Reset-Intervall | 24h, versetzt pro Node | 5 |
| Redundanz-Empfehlung | Mindestens 2 eigene Nodes für Migrationsfähigkeit | 5 |
| Ein-Node-Migration | Kein automatischer Pfad — dokumentierte Einschränkung, manuelles Re-Pairing | 6 |
| Temp-Node-Bootstrap | Löst sich durch die neue Schreibrichtung von selbst, kein Sondercode nötig | 7 |
| Implementierungs-Basis | Bestehender `server/`/`relay-android/`-Code, gezielt angepasst, nicht neu gebaut | 8 |
| Per-Tag-Speicher-Cap | Ausgangswert vom bestehenden Relay übernehmen, gegen neue Defaults durchrechnen | 8, 9 |
| **[v5]** Rotation | Protokoll-Konstante 1 h, nicht pro Node konfigurierbar (beide Seiten müssen übereinstimmen) | 3 |
| **[v5]** TTL-Konfiguration | Nur über Profile (6/1/24 h), Maximum 24 h | 3 |
| **[v5]** Client-Toleranzfenster | Immer für MAX_TTL (24 h) berechnet — 26 Tags/Kontakt, deckt jedes Profil ab | 3 |
| **[v5]** Tor | Eingebaut und Pflicht; `ADD_ONION` mit festem Schlüssel, Tor-PoW an, Selbstheilung | 8 |
| **[v5]** Flood-Schutz | Tor-PoW (PC/Server) + App-Token-Bucket auf Lese-Endpunkten (alle Plattformen) | 8 |
| **[v5]** Reset-Takt | Slot 1/2/3 → Minute 0/20/40, an UTC ausgerichtet | 5 |
| **[v5]** Android-Node | `relay-android` Modus "Business Node", eigener Onion-Schlüssel pro Modus, ohne Tor-PoW | 8 |
| **[v5]** Multi-Device | Bewusst nicht vorgesehen — keine Konten, jede Identität = genau ein Gerät | 0, 9 |

---

*unpruuf Business · NexonAI Consulting SRL · Alba Iulia, Romania*

---

## 13. [v6, gebaut 2026‑10‑01] Härtung gegen Beobachtung von außen

Ziel: Wer nur von außen zuschaut (WLAN, Netzbetreiber, ein beschlagnahmter oder mitgeschnittener
Node), soll weder erkennen, **dass** unpruuf läuft, noch **wann** wirklich geschrieben oder ein Chat
geöffnet wird.

1. **Keine WLAN-Ankündigung.** LAN-Erkennung nur, solange ein Direkt-(Onion-)Kontakt existiert; nie in
   Whistleblower, nie bei reinen Business-Nutzern. Dienst-Typ `_http._tcp`, Name = 16 Hex-Zeichen
   HMAC(userId, Stunde) — stündlich neu, nur für Direktkontakte berechenbar, zufälliger Port. Der
   Onion-Socket hört nur auf 127.0.0.1 (`LanDiscovery.kt`).
2. **Ein Abholtakt.** Node-Mesh fragt immer im selben Rhythmus ab (20 s ± 5 s, Long-Poll 20 s), egal ob
   ein Chat offen ist. Kein Extra-Abruf beim Öffnen eines Chats.
3. **Tarn-Ablagen.** Pro Node-Mesh-Kontakt im Mittel eine Dummy-Ablage alle 15 min, exponentiell
   verteilt: gleicher Tag, gleiche Größe, gleiche Nodes wie eine echte Nachricht. Der Empfänger
   entschlüsselt und verwirft sie (`DUMMY_SIGNAL`). Eine Ablage beweist damit keine Nachricht mehr.
4. **Abhol-Cursor.** `POST /fetchMany` nimmt optional `since` (Server-Zeilen-ID) und antwortet mit
   `{"cursor":N,"blobs":{…}}`. Jeder Blob wird nur einmal geladen; Tags, die neu ins Fenster kommen,
   einmal ab 0. Ohne `since` bleibt die Antwort exakt wie vorher. (Android-Node: noch ohne Cursor,
   App fällt dort auf Voll-Abruf zurück.) **Stand 25.10.2026:** Der Cursor kommt nur noch aus den
   angefragten Tags (höchste ID der gelieferten Pakete, sonst das gesendete `since`), nicht mehr aus
   einem Zähler des ganzen Servers; ein Fremder mit einer Adresse sieht so weder den Einwurf-Verkehr
   des Servers noch, welche Adressen zusammengehören. Gleiche Tags in einer Anfrage werden einmal
   gelesen. Eine Antwort trägt höchstens 256 Pakete; wurde sie gekürzt, steht `"more":true` vor
   `blobs`, und die nächste Anfrage mit dem Cursor setzt genau dort fort. Ein Cursor ohne `more`
   heißt: für diese Tags liegt bis jetzt nichts Weiteres bereit, ein Client darf bei mehreren
   Blöcken den größten Cursor übernehmen (bei `more` den kleinsten der gekürzten). Alte Clients
   bleiben korrekt, laden nur gelegentlich etwas doppelt (die Annahme dedupliziert).
   Lese-Bremse: ein eigener Topf je Adresse, die der Server selbst bedient (und je Loopback-Name);
   jeder andere Host-Header teilt sich einen einzigen Topf. **iOS (Norbert):** Cursor-Logik gleich
   nachziehen, `more` auswerten, nur v3-Onion-Adressen annehmen.
5. **Versiegelte Node-Schlüssel (`NODE_MESH_KEY_STORAGE=sealed`, Standard).** Owner-Secret und
   Onion-Schlüssel liegen nur verschlüsselt auf der Platte (AES-256-GCM, Schlüssel per HKDF aus dem
   Owner-Secret, das selbst nirgends gespeichert ist). Nach einem Neustart ist der Server **gesperrt**:
   nur eine Control-Onion (Schlüssel im Klartext, trägt keine Nachrichten) ist online, `/deposit` und
   `/pool` antworten `423`. Die App erfährt die Control-Adresse über `GET /pool` (`"control"`), fragt
   `GET /lock-status` (ohne Geheimnis) und sendet `POST /unlock` (Bearer Owner-Secret) **erst nach
   Bestätigung durch den Nutzer**. Danach gehen die Nodes unter denselben Adressen wieder online.
   Ersatzweg: Owner-Code auf der Einrichtungsseite einfügen. Ein ausgeschalteter, beschlagnahmter
   Server lässt sich damit nicht unter denselben Adressen weiterbetreiben.
   **Grenzen:** Wer den Server hat, kann die Control-Adresse imitieren und auf das Entsperren
   warten — darum Bestätigung mit Warnung („im Zweifel neuen Server aufsetzen“). Ein RAM-Abbild eines
   laufenden VPS (durch den Hoster) enthält die Schlüssel weiterhin. `NODE_MESH_KEY_STORAGE=disk`
   behält das alte Verhalten (unbeaufsichtigte Neustarts).

## 14. Server licence (2026‑10‑06)

A Business Node server runs with an offline-checked licence (`node-mesh-server/src/license.ts`):
`unpruuf-server-license:v1:<b64url payload>:<b64url Ed25519 signature>`, payload
`1|serial|customer|maxNodes|issuedAtMs|expiresAtMs`, signature over `"unpruuf-server-license-v1\n" + payload`
with the same key pair as the app licences. No network, no device identification, no telemetry. The licence
fixes the node count (default and maximum 250; the server always runs exactly that many) and the expiry. Without a licence only the setup page runs; after expiry
deposits are refused with 402 while fetching keeps working. A Temp Node needs none. The server stays
structurally blind: the check reads one local file and learns nothing about users or contacts.

Android node (`relay-android`): the same check (`core/NodeLicense.kt`, same code format and key). One node per
device, so `maxNodes` is read but changes nothing. Without a licence the owner QR stays hidden and deposits are
refused; after expiry deposits are refused (402), reading keeps working.

## 15. Node lists (2026‑10‑06)

**File.** The server's setup page exports `unpruuf-node-list:v1` (plain text): header lines `name`, `secret`
(owner secret for every node of that server), optional `control` (sealed servers), `count`, an empty line, then one
address per line. Parser and writer: `node-mesh-server/src/nodeList.ts`, app: `NodeListFile.kt`; a test pins that the
Kotlin parser reads the real TypeScript output. The file carries the write key: as sensitive as the owner QR.

**Lists in the app.** A list is a named group of own nodes (`NodeLists.kt`). Every node is in exactly one list, a list
with no nodes does not exist, a list may hold the nodes of several servers. Importing a file creates a list (or adds
to an existing one); nodes added by owner QR land in "Standard". Settings → Node lists: import (file or pasted text),
rename, delete (removes the list's nodes from the device; shows how many contacts used them).

**Adding a contact.** The Business QR screen requires a list: the QR carries three nodes from it (picked at random,
spread over as many different servers of the list as possible; nodes are shared between contacts — see §18). With exactly one list it is pre-selected. Changing the
list starts a fresh pairing (new keys), so a half-used QR is never mixed with nodes of another list. Existing
contacts keep the nodes they were given. Design note: a list of ONE server puts all three nodes of a contact on one
machine — put several servers in one list to keep the contact's nodes spread over different hosts.

## 16. Rotating list feed (2026‑10‑06)

**Purpose.** A company keeps its employees' node lists up to date without handing out files again. The company runs
a small service (`node-mesh-server/src/feedIndex.ts`, `start-feed.bat`) on its own server. Its onion address changes
every *period* (1 to 24 hours, default 6). The apps compute the current address; nobody else can find it.

**Address.** `epoch = floor(unixMs / (period h))`. `seed_e = HKDF-SHA256(ikm = addressSeed, salt = "unpruuf-feed-v1",
info = "onion-epoch:" + epoch, 32)`. The Ed25519 key of `seed_e` is the onion service key; address = Tor v3 encoding
(public key, 2-byte SHA3-256 checksum, version 3). The server hands Tor the expanded key (`ED25519-V3:` + 64 bytes:
clamped SHA-512 of the seed) with `ADD_ONION`. It publishes the next period's address 15 minutes before the switch and
keeps the previous one 30 minutes after it (at most two alive); each minute it reconciles. If Tor returns a different
service id than the derived address, the service stops with an error instead of running unreachable. The app tries the
current period first and, within 45 minutes of a boundary, the neighbouring one (phone clock tolerance).

**Three secrets, three places.** *Address seed*: server and apps. *Content key* (AES-256-GCM) and *signing key*
(Ed25519): created at setup, sealed on the server under the admin's passphrase (scrypt + AES-GCM), only needed to
publish. A stolen server reveals where the feed lives; it can neither read nor forge a list.

**Feed code** `unpruuf-feed:v1:1|<name>|<period h>|<address seed>|<content key>|<signing public key>` (base64url): what
the employees' apps get (QR or text). It is a secret of the company.

**List file** (`GET /list`, plain text, no login, the endpoint holds nothing readable):
`unpruuf-feed-list:v1`, `seq`, `issued`, `iv`, `data` (AES-GCM over the node-list files joined by `\n=====\n`, AAD
`unpruuf-feed-v1:<seq>`), `sig` (Ed25519 over `"unpruuf-feed-list-v1\n" seq "\n" issued "\n" iv "\n" data`). The app
checks the signature first, then decrypts, and never accepts a `seq` lower than the one it holds (no rollback).

**In the app** (Settings → Node lists → Company feeds): paste the feed code; the app fetches about hourly (and on
"Update now"). Each list in the feed becomes or updates one managed list of the same name; addresses the company
dropped leave the pool; a managed list the company dropped is removed with its nodes. All or nothing: if the new nodes
do not fit under the device limit, nothing changes. Contacts that were given a removed node keep their other nodes.

**Not built / limits.** Tor client authorization (the service invisible to anyone without a key) is not in; the rotating
address plus an encrypted, signed payload is. Not run against a real Tor in this sandbox: the first test on a real server
is that the setup page reaches "ready" and the app finds the feed. The feed is not covered by the node licence.

## 18. Shared nodes, packet lifetime per chat, RAM store (2026‑10‑08)

**Nodes are shared.** Until now a new contact got the least-used nodes, so that no two contacts shared one. That was dropped.
A node that serves exactly one contact is that contact's fingerprint: whoever sees the traffic on it sees that one
conversation's volume and timing. A node that carries many conversations mixes them. What separates two conversations is the
per-contact keys and the hourly routing tags, not the node. The app now picks 3 nodes at random from the chosen list, one per
server first (`NodeMeshManager.chooseNodes`), and never looks at how often a node is used. What this costs: a compromised node
touches every contact that uses it (hence three nodes per contact). What it gains: mixing grows with the number of active users
per node. The old "room for N contacts with nodes of their own" display (server setup page, overview, licence tool, list
screens, contact picker) is gone with it.

**Capacity, as far as it can be said.** A node takes 5 fetches/s on average (burst 30, `routes/node.ts`). The app polls about
every 20 s with one batched request per node, so roughly 100 concurrently active users per node. Calculated from the code, not
measured; Tor on the customer's hardware is the likelier limit. A load test is still to be done.

**Packet lifetime per chat.** `Contact.messageTtlHours` (1, 6 or 24; null = 24; DB v12, `MIGRATION_11_12`, contacts kept).
`depositForNodeMesh` sends it as the deposit's `ttl` (ms). The server already accepted `ttl` and caps it at the node's own
profile; the Android node does the same (`NodeMeshHttpServer`). Cover deposits use the chat's value too, so cover and real
packets look alike. Only three steps (`MessageTtl`), because the node sees the value. The receiver's poll window is sized for
24 h, so every step is within it. In the chat: clock icon in the top bar (Node-Mesh contacts only).

**RAM store.** `NODE_MESH_STORE=ram` opens the store as `:memory:` for a normal (licensed) server. A restart drops every
waiting packet; the owner secret and node keys are unaffected (sealed on disk, `KEY_STORAGE`). Default stays `disk`. The
Temp Node is always in memory. `start.bat` asks once and remembers it in `node.env.bat`. Not covered: the Android node
(`relay-android`) still keeps packets in its SQLite file.

## 19. Release integrity (2026‑10‑10)

**Purpose.** An operator, a customer or an auditor can ask "is this the program NexonAI shipped, and is it unchanged?". The answer is a signed list of hashes, not a promise.

**Format.** `release-manifest.txt` next to `dist/`: header `unpruuf-release:v1`, `version:`, `files:`, then one `<sha256>␣␣<path>` line per covered file (all `.js` under `dist/` except tests, plus `package.json`; sorted; "/" separators), then `signature:` (base64url Ed25519). The signed bytes are `"unpruuf-release-v1\n"` plus everything above the signature line. Same key pair as the licences, own signing domain: a licence signature never verifies as a release signature, nor the reverse (test `integrity.test.ts`). Fingerprint = SHA-256 of the signed body, 16 groups of four hex digits. `tsconfig.json` sets `newLine: lf` so a build on Windows and one on Linux produce the same bytes.

**Check.** `integrity.ts` `verifyIntegrity`: states `ok`, `modified` (changed / missing / extra files named), `bad-signature`, `unsigned` (no manifest: development checkout, not an alarm), `exe` (single-file build: SHA-256 of the program file only). At start and hourly; shown on the overview and setup page; a `modified` or `bad-signature` result raises the "Achtung" banner. `NODE_MESH_REQUIRE_SIGNED=1` exits when the state is not `ok`/`exe`.

**Signing.** Offline in `license-tool`: `sign-release.js` or the "Sign a server release" card in the tool's page. It builds the body with the server's own compiled `integrity.js`, so signer and checker cannot disagree. The fingerprint is appended to `release-fingerprints.txt` for publishing.

**Outside check.** `verify-release.js` (`.bat`/`.sh`) on a copy of the files, optionally with the published fingerprint.

**Limits.** Self-check: a server compromised while running can lie about itself, and someone who can edit the files can edit the check. Not covered: `node_modules` (native, platform-specific) and the data folder. Real remote attestation would need hardware (TPM, protected environments) and is not built.

## 20. Connection paths and the company bridge (2026‑10‑11)

**Purpose.** The app must reach Tor even where a network blocks it, without asking a person to find bridge lines.

**Automatic connection (app).** `ConnectionPaths` / `TorManager.runAssistant`. Tor starts bootstrapping direct by itself; the assistant watches `status/bootstrap-phase`. If a path does not reach 100 % within its time budget (direct 30 s, company 40 s, obfs4 45 s, Snowflake 90 s) it applies the next one over the control port: `DIRECT`, then `COMPANY` (only if the company has a bridge), `OBFS4` (the public default bridges Tor Browser ships), `SNOWFLAKE`. The path that worked is remembered and tried first at the next app start only; after a network change the direct path is looked at first again. If Tor has no circuit 25 s after a network change, the assistant runs again. If everything fails, the app returns to direct and tries again after 5 minutes. Hand-entered bridges (Settings) always take precedence; then the assistant stays out and the lines are applied at once (TorService only reports "on" after the first circuit, so waiting for that would never come on a blocked network). A transport without a running local client is never written into the Tor configuration.

**Company bridge.** A private (unpublished) Tor bridge with an obfs4 front on a small separate server (`bridgeIndex.ts`, `bridge/bridgeTorrc.ts`): `BridgeRelay 1`, `PublishServerDescriptor 0`, lyrebird as server transport. It prints a bridge line (`obfs4 <address>:<port> <fingerprint> cert=… iat-mode=0`). The line goes on the node server's setup page, which exports it as `bridge:` header lines in the node-list file (at most 10 lines, only obfs4 and plain `IP:PORT [FINGERPRINT]`, one line each, no control characters) and therefore also in the company feed, which publishes the list files unchanged. The app stores the lines (BridgeManager) and uses them as path `COMPANY`.

**Limits.** Bridges protect against blocking, not against being noticed. A bridge line is a secret of the group that received it; one leaked line lets an adversary block that bridge. Snowflake uses other people's machines. Not tested: Snowflake and the public bridges on a network that really blocks Tor; a full bootstrap through the company bridge (here the bridge itself could not finish bootstrapping; a Tor client did connect to it over obfs4 and requested the consensus). iOS: Norbert to carry the same path logic and the `bridge:` list line.

