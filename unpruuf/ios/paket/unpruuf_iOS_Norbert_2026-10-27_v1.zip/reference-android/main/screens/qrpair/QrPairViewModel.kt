package com.nexonai.unpruuf.screens.qrpair

import com.nexonai.unpruuf.R

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexonai.unpruuf.data.db.ContactDao
import com.nexonai.unpruuf.data.model.Contact
import com.nexonai.unpruuf.domain.AppEdition
import com.nexonai.unpruuf.domain.network.GuestClient
import com.nexonai.unpruuf.domain.network.GuestGrant
import com.nexonai.unpruuf.domain.network.IdentityManager
import com.nexonai.unpruuf.domain.network.NodeMeshManager
import com.nexonai.unpruuf.domain.network.P2PNetworkManager
import com.nexonai.unpruuf.domain.network.RelayManager
import com.nexonai.unpruuf.domain.network.TorManager
import com.nexonai.unpruuf.domain.network.ratchet.RatchetSessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject

data class QrPairingPayload(
    val version: Int = 5,
    val userId: String,
    val onionAddress: String,
    val publicKeyBase64: String,
    val rotationFactorBase64: String,
    val displayName: String,
    val appEdition: String, // Werte: "standard", "pro" oder "client"
    // Raw X25519 identity public key (32 bytes, Base64) — bootstraps this
    // contact's Double Ratchet session (see RatchetSessionManager / IdentityManager).
    val x25519RatchetPublicKeyBase64: String = "",
    // v5: the relay pool this device advertises, up to RelayManager.RELAY_POOL_MAX_SIZE entries.
    // Before this existed, the relay path between two Android devices only worked if BOTH had
    // manually configured the SAME relay — the sender pushed to its own global relay and the
    // receiver polled its own, so two differently-configured devices never met (the standard QR
    // carried no relay field at all, unlike the cross-platform one). Empty when no relay is
    // configured, and then nothing is written into the QR either — see [payloadToJson].
    val relayConnectionStrings: List<String> = emptyList(),
    val timestampMs: Long = System.currentTimeMillis()
)

/** Constant head of every connection string — stripped in the QR, re-added on parse. Must stay
 *  in sync with RelayManager's own private PREFIX and server/src/connectionString.ts. */
private const val RELAY_STRING_PREFIX = "unpruuf-relay:v1:"

@HiltViewModel
class QrPairViewModel @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: android.content.Context,
    private val contactDao: ContactDao,
    private val identityManager: IdentityManager,
    private val torManager: TorManager,
    private val ratchetSessionManager: RatchetSessionManager,
    private val relayManager: RelayManager,
    private val nodeMeshManager: NodeMeshManager,
    private val p2pNetworkManager: P2PNetworkManager,
    private val whistleblowerCases: com.nexonai.unpruuf.domain.WhistleblowerCases
) : ViewModel() {
    private fun str(@androidx.annotation.StringRes id: Int, vararg args: Any): String = context.getString(id, *args)


    private val _errorState = MutableStateFlow<String?>(null)
    val errorState = _errorState.asStateFlow()

    private val _successState = MutableStateFlow<String?>(null)
    val successState = _successState.asStateFlow()

    /** Client app: after an invitation is accepted, the guest's own code the inviter has to scan
     *  (GUEST_LOCKERS_BUILD_SPEC.md §4). Shown once; rebuilt from the contact if needed. */
    data class GuestCode(val json: String, val inviterName: String, val fingerprint: String)

    private val _guestCode = MutableStateFlow<GuestCode?>(null)
    val guestCode = _guestCode.asStateFlow()
    fun clearGuestCode() { _guestCode.value = null }

    private val _myQrPayload = MutableStateFlow<QrPairingPayload?>(null)
    val myQrPayload = _myQrPayload.asStateFlow()

    private var onionQrRequested = false

    /** Starts the device's own onion service on demand — only the onion-format QR needs one,
     *  so Node-Mesh and relay-only users never publish an onion just by opening this screen. */
    fun requestOnionQr() {
        if (onionQrRequested) return
        onionQrRequested = true
        generateMyQrCode()
    }

    fun isNodeMeshUsable(): Boolean = nodeMeshManager.isUsable()

    private fun generateMyQrCode() {
        viewModelScope.launch {
            // Wiederholen, bis eine ECHTE Onion vorliegt. myQrPayload wird erst
            // gesetzt, wenn die Onion gültig ist → der Screen zeigt bis dahin den
            // Warte-Zustand statt eines ungültigen QR-Codes.
            repeat(30) {
                withTimeoutOrNull(60_000) { torManager.isReady.filter { it }.first() }
                val onion = torManager.ensureMainOnion()
                if (onion.endsWith(".onion") && onion != "pending.onion") {
                    _myQrPayload.value = createMyQrPayload(
                        userId = identityManager.userId,
                        onion = onion,
                        pubKey = android.util.Base64.encodeToString(
                            identityManager.myMessageKey,
                            android.util.Base64.NO_WRAP
                        ),
                        rotFactor = identityManager.getCurrentRotationFactor(),
                        name = "",
                        ratchetPubKey = identityManager.myX25519RatchetPublicKeyBase64,
                        relays = relayManager.getMyRelayPool()
                    )
                    return@launch
                }
                kotlinx.coroutines.delay(3_000)
            }
        }
    }

    // Erstellt den eigenen QR Code für die Standard-App
    fun createMyQrPayload(
        userId: String,
        onion: String,
        pubKey: String,
        rotFactor: String,
        name: String,
        ratchetPubKey: String = "",
        relays: List<String> = emptyList()
    ): QrPairingPayload {
        return QrPairingPayload(
            userId = userId,
            onionAddress = onion,
            publicKeyBase64 = pubKey,
            rotationFactorBase64 = rotFactor,
            displayName = name,
            appEdition = AppEdition.current,
            x25519RatchetPublicKeyBase64 = ratchetPubKey,
            relayConnectionStrings = relays
        )
    }

    // Wenn ein QR-Code mit der Kamera gescannt wird
    fun handleScannedQr(payload: QrPairingPayload, displayName: String) {
        viewModelScope.launch {
            // Edition-Pairing-Regeln durchsetzen (Pro/Standard/Client).
            if (!AppEdition.canAdd(payload.appEdition)) {
                _errorState.value = AppEdition.blockReason(context, payload.appEdition)
                return@launch
            }

            // Invalid onion address → contact would be permanently unreachable
            if (payload.onionAddress == "pending.onion" || !payload.onionAddress.endsWith(".onion")) {
                _errorState.value = str(R.string.msg_qr_tor_not_ready)
                return@launch
            }

            // Older app versions didn't include a ratchet key — reject rather
            // than silently create a contact that can never receive messages.
            if (payload.x25519RatchetPublicKeyBase64.isBlank()) {
                _errorState.value = str(R.string.msg_qr_old_version)
                return@launch
            }

            // A QR claiming to be a contact we already have — block a silent overwrite instead
            // of letting Room's REPLACE quietly swap in new keys under an already-trusted name
            // (fixed 2026-09-17, see SECURITY_CLAIMS.md). Harmless identical re-scans (both
            // devices already paired, one side just scanned again) fall through as a no-op
            // rather than creating a duplicate contact row.
            val existing = contactDao.getContactByRemoteUserId(payload.userId)
            if (existing != null) {
                if (existing.publicKey != payload.publicKeyBase64 ||
                    existing.x25519RatchetPublicKey != payload.x25519RatchetPublicKeyBase64
                ) {
                    _errorState.value = str(R.string.msg_qr_key_changed)
                } else {
                    _successState.value = str(R.string.msg_contact_exists, displayName)
                }
                return@launch
            }

            val contact = Contact(
                id = identityManager.newWireIdentity(),
                onionAddress = payload.onionAddress,
                publicKey = payload.publicKeyBase64,
                rotationFactor = payload.rotationFactorBase64,
                displayName = displayName,
                isClientSlot = payload.appEdition == AppEdition.CLIENT,
                x25519RatchetPublicKey = payload.x25519RatchetPublicKeyBase64,
                remoteUserId = payload.userId,
                myWireIdentity = identityManager.newWireIdentity(),
                // v5: both sides' relay pools are fixed at pairing time. Mine is what I just
                // advertised in my own QR — it must be stored per contact rather than read live
                // later, because THEY will keep pushing to whatever I showed them, even if I
                // reconfigure my relay afterwards (see P2PNetworkManager.pollRelayOnce).
                myRelayConnectionString = RelayManager.buildConnectionStringList(relayManager.getMyRelayPool()),
                theirRelayConnectionString = RelayManager.buildConnectionStringList(payload.relayConnectionStrings)
            )

            contactDao.insert(contact)
            // Both devices already know both X25519 keys at this point (mutual QR
            // exchange) — no async handshake needed before the ratchet session exists.
            ratchetSessionManager.createSession(contact)
            // Tell them our fresh per-contact identity right away — see Contact.kt and
            // P2PNetworkManager.sendNewIdentitySignal()'s doc comments.
            p2pNetworkManager.sendNewIdentitySignal(contact.id)
            // Onion pro Gerät (Haupt-Onion) → kein per-Kontakt-confirmPairing nötig.
            _successState.value = str(R.string.msg_contact_added, displayName)
        }
    }

    // ─── Cross-platform (iOS-interop) pairing — see CROSS_PLATFORM_PLAN.md ─────────────────
    // Structurally separate from the onion-based flow above, not a variant of it: no onion
    // involved, relay-mandatory, gated to Pro only (the format itself carries no edition field
    // — iOS has no Standard/Client concept, so "both sides are Pro" is the only rule there is
    // to enforce here; AppEdition.canAdd()'s edition matrix is unrelated and untouched).

    /** Null until a relay is configured in Settings (Settings → Relay) — the cross-platform QR
     *  is meaningless without one, since its whole point is "the relay that reaches me". */
    fun myCrossPlatformQrPayload(): CrossPlatformPairingPayload? {
        val pool = relayManager.getMyRelayPool().ifEmpty { if (AppEdition.isWhistleblower) whistleblowerOfficerRelays() else emptyList() }
        if (pool.isEmpty()) return null
        return CrossPlatformPairingPayload(
            userId = identityManager.userId,
            messageKeyBase64 = android.util.Base64.encodeToString(
                identityManager.myMessageKey, android.util.Base64.NO_WRAP
            ),
            x25519RatchetPublicKeyBase64 = identityManager.myX25519RatchetPublicKeyBase64,
            relayConnectionStrings = pool,
            appEdition = AppEdition.current
        )
    }

    // The officer's relays, once paired — what a reporter without an own relay receives over.
    private fun whistleblowerOfficerRelays(): List<String> = runBlocking {
        contactDao.getAllContactsOnce().firstOrNull()?.let { RelayManager.parseConnectionStringList(it.myRelayConnectionString ?: "") } ?: emptyList()
    }

    /** True when Settings → Relay is set to Mandatory — the QR screen uses this to default to
     *  the no-onion cross-platform-format pairing automatically for Android↔Android contacts
     *  too, not just genuine iOS interop, since Mandatory means an onion will never be used for
     *  this device's traffic anyway (see CHANGELOG "Business/Mandatory pairing unification"). */
    fun isRelayMandatory(): Boolean = relayManager.isMandatory()

    fun handleScannedCrossPlatformQr(payload: CrossPlatformPairingPayload, displayName: String) {
        viewModelScope.launch {
            // Whistleblower: an officer QR is the organisation — every case gets its own keys
            // (WhistleblowerCases), never the global ones used below.
            if (AppEdition.isWhistleblower && payload.appEdition == AppEdition.OFFICER) {
                when (whistleblowerCases.connectOrganization(crossPlatformPayloadToJson(payload))) {
                    is com.nexonai.unpruuf.domain.WhistleblowerCases.ScanResult.Ok -> _successState.value = str(R.string.msg_contact_added, displayName)
                    is com.nexonai.unpruuf.domain.WhistleblowerCases.ScanResult.Invalid -> _errorState.value = AppEdition.blockReason(context, payload.appEdition)
                }
                return@launch
            }
            // Cross-platform-format pairing is a paid Pro feature for genuine iOS interop — but
            // the same wire format is now also what Mandatory relay mode uses for Android↔Android
            // pairing (see isRelayMandatory's doc comment), where gating behind Pro would block
            // exactly the Business/Node customers this mode exists for. Waive the check whenever
            // Mandatory is the reason this format is in use; the deliberate manual "iOS /
            // cross-platform" toggle on Standard/Client still requires Pro as before.
            if (!AppEdition.isPro && !relayManager.isMandatory()) {
                _errorState.value = str(R.string.msg_qr_ios_pro)
                return@launch
            }
            // The payload carries no edition field from iOS (defaults to STANDARD — see
            // CrossPlatformPairingPayload's doc comment) or from an old Android QR, but two real
            // Android editions pairing this way under Mandatory still need the normal
            // Client-can-only-add-Pro rule enforced, same as the onion-based flow below.
            if (!AppEdition.canAdd(payload.appEdition)) {
                _errorState.value = AppEdition.blockReason(context, payload.appEdition)
                return@launch
            }
            if (payload.relayConnectionStrings.none { RelayManager.parseConnectionString(it) != null }) {
                _errorState.value = str(R.string.msg_qr_relay_invalid)
                return@launch
            }
            if (payload.x25519RatchetPublicKeyBase64.isBlank()) {
                _errorState.value = str(R.string.msg_qr_old_version)
                return@launch
            }

            val existing = contactDao.getContactByRemoteUserId(payload.userId)
            if (existing != null) {
                if (existing.publicKey != payload.messageKeyBase64 ||
                    existing.x25519RatchetPublicKey != payload.x25519RatchetPublicKeyBase64
                ) {
                    _errorState.value = str(R.string.msg_qr_key_changed)
                } else {
                    _successState.value = str(R.string.msg_contact_exists, displayName)
                }
                return@launch
            }

            // Whistleblower reporters normally have no relay of their own: they receive over the
            // officer's relay from the QR. Without this fallback myRelayConnectionString stayed
            // empty, so the app never polled anywhere and the officer's replies never arrived.
            val myRelays = relayManager.getMyRelayPool().ifEmpty {
                if (AppEdition.isWhistleblower) payload.relayConnectionStrings.take(RelayManager.RELAY_POOL_MAX_SIZE) else emptyList()
            }
            val contact = Contact(
                id = identityManager.newWireIdentity(),
                onionAddress = "",
                publicKey = payload.messageKeyBase64,
                rotationFactor = "",
                displayName = displayName,
                isClientSlot = payload.appEdition == AppEdition.CLIENT,
                x25519RatchetPublicKey = payload.x25519RatchetPublicKeyBase64,
                crossPlatform = true,
                myRelayConnectionString = RelayManager.buildConnectionStringList(myRelays),
                theirRelayConnectionString = RelayManager.buildConnectionStringList(payload.relayConnectionStrings),
                remoteUserId = payload.userId,
                myWireIdentity = identityManager.newWireIdentity()
            )

            contactDao.insert(contact)
            ratchetSessionManager.createSession(contact)
            p2pNetworkManager.sendNewIdentitySignal(contact.id)
            _successState.value = str(R.string.msg_contact_added, displayName)
        }
    }

    // ─── unpruuf Business / Node-Mesh pairing — see NODE_MESH_SPEC.md ──────────────────────
    // Its own third format, not a variant of either above: no onion, no relay-pool-with-token,
    // no wire-identity concept at all (see IdentityManager.nodeMeshRoutingTag's doc comment for
    // why routing needs none). Gated purely on NodeMeshManager.isUsable() — at least one own
    // node configured — not on edition, matching how this transport is meant to work regardless
    // of Standard/Pro/Client tier; AppEdition.canAdd() is still enforced on scan, same as every
    // other pairing format, since the Client-can-only-add-Pro business rule is orthogonal to
    // which transport a pairing uses.

    /** Null until at least one own node is configured (Settings → Business Node-Mesh) — the
     *  Node-Mesh QR is meaningless without one, mirroring [myCrossPlatformQrPayload]'s same gate
     *  for the relay pool. */
    // The pairing values shown on THIS screen. Kept for the screen's lifetime, even after a scan
    // has bound them to a contact, because the other side may still need to scan this QR.
    private var shownNodeMeshPairing: IdentityManager.PendingNodeMeshPairing? = null
    private var nodeMeshPairingBound = false

    /** A list a new contact can be given nodes from, with what the picker shows about it. */
    data class NodeListChoice(
        val id: String,
        val name: String,
        val nodeCount: Int,
        val serverCount: Int,
    )

    fun nodeListChoices(): List<NodeListChoice> {
        return nodeMeshManager.getNodeLists().map { l ->
            NodeListChoice(l.id, l.name, l.addresses.size, nodeMeshManager.serverCount(l))
        }
    }

    // Which list the contact being added gets its nodes from. Must be chosen before a QR is shown:
    // the QR carries the three nodes picked from it. With exactly one list it is chosen for you.
    private val _selectedNodeListId = MutableStateFlow<String?>(initialNodeListId())
    val selectedNodeListId = _selectedNodeListId.asStateFlow()

    private fun initialNodeListId(): String? {
        val lists = nodeMeshManager.getNodeLists()
        // A QR that is already pending (screen left and reopened) keeps the list it was made from.
        identityManager.peekPendingNodeMeshPairing()?.let { pending ->
            lists.find { l -> pending.nodeAddresses.any { it in l.addresses } }?.let { return it.id }
        }
        return lists.singleOrNull()?.id
    }

    /** Picking another list starts a fresh pairing (new keys, nodes from that list) — a QR that was
     *  already scanned by the other side must not be mixed with nodes of a different list. */
    fun selectNodeList(listId: String) {
        if (_selectedNodeListId.value == listId) return
        identityManager.clearPendingNodeMeshPairing()
        shownNodeMeshPairing = null
        nodeMeshPairingBound = false
        _selectedNodeListId.value = listId
    }

    private fun currentNodeMeshPairing(): IdentityManager.PendingNodeMeshPairing? {
        shownNodeMeshPairing?.let { return it }
        if (!nodeMeshManager.isUsable()) return null
        val listId = _selectedNodeListId.value ?: return null
        val list = nodeMeshManager.getNodeLists().find { it.id == listId }
        if (list == null) {
            // the list was deleted meanwhile
            _selectedNodeListId.value = null
            identityManager.clearPendingNodeMeshPairing()
            return null
        }
        val pending = identityManager.pendingNodeMeshPairing {
            nodeMeshManager.chooseNodesForNewContact(listId)
        }
        // A pending set that does not come from the selected list (list changed or its nodes were
        // removed meanwhile) is useless — start fresh from the selected list.
        if (pending.nodeAddresses.none { it in list.addresses }) {
            identityManager.clearPendingNodeMeshPairing()
            val fresh = identityManager.pendingNodeMeshPairing {
                nodeMeshManager.chooseNodesForNewContact(listId)
            }
            shownNodeMeshPairing = fresh
            return fresh
        }
        shownNodeMeshPairing = pending
        return pending
    }

    fun myNodeMeshQrPayload(): NodeMeshPairingPayload? {
        val pairing = currentNodeMeshPairing() ?: return null
        return NodeMeshPairingPayload(
            messageKeyBase64 = pairing.messageKey,
            x25519RatchetPublicKeyBase64 = pairing.ratchetPublicKey,
            nodeMeshRoutingSeedBase64 = pairing.routingSeed,
            nodeAddresses = pairing.nodeAddresses,
            appEdition = AppEdition.current
        )
    }

    /** Pro app: a guest's answer that was PASTED, waiting for the inviter to compare the check
     *  code with the one on the guest's phone (GUEST_LOCKERS_BUILD_SPEC.md §15.1). */
    data class GuestAnswerToConfirm(val payload: NodeMeshPairingPayload, val displayName: String, val fingerprint: String)

    private val _guestAnswerToConfirm = MutableStateFlow<GuestAnswerToConfirm?>(null)
    val guestAnswerToConfirm = _guestAnswerToConfirm.asStateFlow()

    fun cancelGuestAnswer() { _guestAnswerToConfirm.value = null }

    /** The inviter has compared the check code and it matches: add the guest now. */
    fun confirmGuestAnswer() {
        val pending = _guestAnswerToConfirm.value ?: return
        _guestAnswerToConfirm.value = null
        handleScannedNodeMeshQr(pending.payload, pending.displayName, pasted = false)
    }

    /** [pasted] = the code came through the paste field, not the camera: a guest's answer then
     *  needs the check-code confirmation first, because nobody verified the phones were together. */
    fun handleScannedNodeMeshQr(payload: NodeMeshPairingPayload, displayName: String, pasted: Boolean = false) {
        viewModelScope.launch {
            if (!AppEdition.canAdd(payload.appEdition)) {
                _errorState.value = AppEdition.blockReason(context, payload.appEdition)
                return@launch
            }
            // A guest invitation (Pro → Client): only the free Client app can accept it.
            if (payload.guestGrants.any { it.isNotEmpty() }) {
                if (AppEdition.isClient) importGuestInvitation(payload, displayName)
                else _errorState.value = str(R.string.msg_guest_invite_client_only)
                return@launch
            }
            // The guest's own code answering one of our invitations (Client → Pro).
            if (payload.guestInviteId.isNotEmpty() && payload.appEdition == AppEdition.CLIENT) {
                if (pasted) {
                    _guestAnswerToConfirm.value = GuestAnswerToConfirm(
                        payload, displayName,
                        GuestClient.fingerprint(payload.messageKeyBase64, payload.x25519RatchetPublicKeyBase64, payload.guestInviteId)
                    )
                } else {
                    bindGuestInvitation(payload, displayName)
                }
                return@launch
            }
            if (payload.nodeAddresses.isEmpty()) {
                _errorState.value = str(R.string.msg_qr_node_invalid)
                return@launch
            }
            if (payload.x25519RatchetPublicKeyBase64.isBlank() || payload.nodeMeshRoutingSeedBase64.isBlank()) {
                _errorState.value = str(R.string.msg_qr_old_version)
                return@launch
            }
            if (!nodeMeshManager.isUsable()) {
                _errorState.value = str(R.string.msg_qr_own_node_first)
                return@launch
            }

            // No userId in this format, so the message key is the re-scan key. A reset device
            // gets a fresh message key and therefore pairs as a new contact.
            val existing = contactDao.getNodeMeshContactByPublicKey(payload.messageKeyBase64)
            if (existing != null) {
                if (existing.x25519RatchetPublicKey != payload.x25519RatchetPublicKeyBase64) {
                    _errorState.value = str(R.string.msg_qr_key_changed)
                } else {
                    _successState.value = str(R.string.msg_contact_exists, displayName)
                }
                return@launch
            }

            if (nodeMeshPairingBound) {
                _errorState.value = str(R.string.msg_qr_code_used)
                return@launch
            }
            val mine = currentNodeMeshPairing() ?: run {
                _errorState.value = if (nodeMeshManager.isUsable())
                    str(R.string.msg_qr_choose_list)
                else
                    str(R.string.msg_qr_own_node_first)
                return@launch
            }
            val contact = Contact(
                id = identityManager.newWireIdentity(),
                onionAddress = "",
                publicKey = payload.messageKeyBase64,
                rotationFactor = "",
                displayName = displayName,
                isClientSlot = payload.appEdition == AppEdition.CLIENT,
                x25519RatchetPublicKey = payload.x25519RatchetPublicKeyBase64,
                nodeMesh = true,
                myPairMessageKey = mine.messageKey,
                myPairRatchetPrivateKey = mine.ratchetPrivateKey,
                myPairRatchetPublicKey = mine.ratchetPublicKey,
                myPairRoutingSeed = mine.routingSeed,
                myNodeAddresses = mine.nodeAddresses.joinToString(";") { NodeMeshManager.buildAddressConnectionString(it) },
                theirNodeMeshRoutingSeed = payload.nodeMeshRoutingSeedBase64,
                theirNodeAddresses = NodeMeshManager.buildNodeConnectionStringList(payload.nodeAddresses)
            )

            contactDao.insert(contact)
            identityManager.clearPendingNodeMeshPairing()
            nodeMeshPairingBound = true
            ratchetSessionManager.createSession(contact)
            // No NEW_IDENTITY signal here, deliberately — Node-Mesh's routing tag has no
            // identity component to announce (see IdentityManager.nodeMeshRoutingTag's doc
            // comment), so myWireIdentity stays null for this contact and sendNewIdentitySignal
            // would have nothing correct to send.
            _successState.value = str(R.string.msg_contact_added, displayName)
        }
    }

    // ─── Guest invitations (GUEST_LOCKERS_BUILD_SPEC.md §4) ───────────────────────────────────

    /**
     * Client app: accepts a Pro user's invitation. The Client has no servers of its own, so the
     * contact's "own nodes" are the inviter's nodes, and every deposit there carries the grant
     * issued for that node. Nothing is sent here; the guest's code (keys and the same nodes) is
     * shown so the inviter can scan it, which is what gives the inviter the guest's keys.
     */
    private suspend fun importGuestInvitation(payload: NodeMeshPairingPayload, displayName: String) {
        if (payload.x25519RatchetPublicKeyBase64.isBlank() || payload.nodeMeshRoutingSeedBase64.isBlank()) {
            _errorState.value = str(R.string.msg_qr_old_version)
            return
        }
        val check = GuestClient.check(payload.nodeAddresses, payload.guestGrants, System.currentTimeMillis())
        val ok = when (check) {
            is GuestClient.Check.Refused -> {
                _errorState.value = str(
                    if (check.problem == GuestClient.Problem.EXPIRED) R.string.msg_guest_invite_expired
                    else R.string.msg_guest_invite_invalid
                )
                return
            }
            is GuestClient.Check.Ok -> check
        }
        val existing = contactDao.getNodeMeshContactByPublicKey(payload.messageKeyBase64)
        if (existing != null) {
            _successState.value = str(R.string.msg_contact_exists, displayName)
            return
        }
        val mine = identityManager.freshNodeMeshPairing(ok.nodeAddresses)
        val nodeList = NodeMeshManager.buildNodeConnectionStringList(ok.nodeAddresses)
        val contact = Contact(
            id = identityManager.newWireIdentity(),
            onionAddress = "",
            publicKey = payload.messageKeyBase64,
            rotationFactor = "",
            displayName = displayName,
            x25519RatchetPublicKey = payload.x25519RatchetPublicKeyBase64,
            nodeMesh = true,
            myPairMessageKey = mine.messageKey,
            myPairRatchetPrivateKey = mine.ratchetPrivateKey,
            myPairRatchetPublicKey = mine.ratchetPublicKey,
            myPairRoutingSeed = mine.routingSeed,
            // The inviter's nodes are where this guest writes and reads; no own node exists.
            myNodeAddresses = nodeList,
            theirNodeMeshRoutingSeed = payload.nodeMeshRoutingSeedBase64,
            theirNodeAddresses = nodeList,
            guestGrants = GuestGrant.encodeList(ok.grants)
        )
        contactDao.insert(contact)
        ratchetSessionManager.createSession(contact)
        _guestCode.value = GuestCode(
            guestCodeJson(contact, payload.guestInviteId), displayName,
            GuestClient.fingerprint(contact.myPairMessageKey ?: "", contact.myPairRatchetPublicKey ?: "", payload.guestInviteId)
        )
        _successState.value = str(R.string.msg_guest_invite_accepted, displayName)
    }

    /** The guest's own code for [contact] (its keys, the inviter's nodes, the invitation id). */
    private fun guestCodeJson(contact: Contact, inviteId: String): String =
        nodeMeshPayloadToJson(
            NodeMeshPairingPayload(
                messageKeyBase64 = contact.myPairMessageKey ?: "",
                x25519RatchetPublicKeyBase64 = contact.myPairRatchetPublicKey ?: "",
                nodeMeshRoutingSeedBase64 = contact.myPairRoutingSeed ?: "",
                nodeAddresses = NodeMeshManager.parseNodeConnectionStringList(contact.theirNodeAddresses ?: ""),
                appEdition = AppEdition.CLIENT,
                guestInviteId = inviteId
            )
        )

    /**
     * Pro app: the guest's own code arrives (scanned in person or pasted). The matching open
     * invitation supplies this contact's own keys and nodes, the guest's code supplies theirs.
     * Without an open, unexpired invitation with that id nothing is added.
     */
    private suspend fun bindGuestInvitation(payload: NodeMeshPairingPayload, displayName: String) {
        if (payload.nodeAddresses.isEmpty()) { _errorState.value = str(R.string.msg_qr_node_invalid); return }
        if (payload.x25519RatchetPublicKeyBase64.isBlank() || payload.nodeMeshRoutingSeedBase64.isBlank()) {
            _errorState.value = str(R.string.msg_qr_old_version)
            return
        }
        val invitation = identityManager.guestInvitation(payload.guestInviteId) ?: run {
            _errorState.value = str(R.string.msg_guest_code_unknown)
            return
        }
        // The guest may only name nodes this invitation gave it: anything else is not our answer.
        val invitedNodes = invitation.pairing.nodeAddresses.toSet()
        val answeredNodes = payload.nodeAddresses.mapNotNull { NodeMeshManager.parseAddressConnectionString(it) }
        if (answeredNodes.isEmpty() || !invitedNodes.containsAll(answeredNodes)) {
            _errorState.value = str(R.string.msg_guest_code_unknown)
            return
        }
        val existing = contactDao.getNodeMeshContactByPublicKey(payload.messageKeyBase64)
        if (existing != null) {
            _successState.value = str(R.string.msg_contact_exists, displayName)
            return
        }
        val mine = invitation.pairing
        val contact = Contact(
            id = identityManager.newWireIdentity(),
            onionAddress = "",
            publicKey = payload.messageKeyBase64,
            rotationFactor = "",
            displayName = displayName,
            isClientSlot = true,
            x25519RatchetPublicKey = payload.x25519RatchetPublicKeyBase64,
            nodeMesh = true,
            myPairMessageKey = mine.messageKey,
            myPairRatchetPrivateKey = mine.ratchetPrivateKey,
            myPairRatchetPublicKey = mine.ratchetPublicKey,
            myPairRoutingSeed = mine.routingSeed,
            myNodeAddresses = mine.nodeAddresses.joinToString(";") { NodeMeshManager.buildAddressConnectionString(it) },
            theirNodeMeshRoutingSeed = payload.nodeMeshRoutingSeedBase64,
            // The guest writes on these (our own) nodes, so we read them there.
            theirNodeAddresses = NodeMeshManager.buildNodeConnectionStringList(payload.nodeAddresses),
            // Automatic renewal as promised in the invitation; the first grants were issued when
            // the invitation was made, which is its expiry minus the validity.
            guestRenewal = invitation.renewal.ifEmpty { null },
            guestRenewedAtMs = com.nexonai.unpruuf.domain.network.GuestRenewal.decodePolicy(invitation.renewal)
                ?.let { invitation.expiresAtMs - it.validityDays * 24L * 3600 * 1000 }
        )
        contactDao.insert(contact)
        identityManager.removeGuestInvitation(invitation.id)
        ratchetSessionManager.createSession(contact)
        _successState.value = str(R.string.msg_contact_added, displayName)
    }

    fun clearError() { _errorState.value = null }

    /** Scanned content wasn't a valid unpruuf QR code — usually an older app
     *  version on the other device (v3 changed the QR's wire format). */
    fun showUnreadableQrError() {
        _errorState.value = str(R.string.msg_qr_unreadable)
    }

    fun clearSuccess() { _successState.value = null }

    // ─── Compact wire format (v3) ────────────────────────────────────────────
    // The QR code's own physical size is fixed (fits the screen), so the only
    // way to make it easier for weak-autofocus/budget cameras (reported: Galaxy
    // S23 Ultra, Honor 5X) to scan is to shrink the payload — fewer bytes means
    // a lower QR version, which means larger, easier-to-resolve modules for the
    // same on-screen size. Short single-letter keys and a compact 16-byte UUID
    // encoding (instead of the 36-char dashed string) cut the payload from
    // ~477 to ~320 chars, dropping the QR from version 13 (69x69 modules) to
    // version 10 (57x57 modules) — about 30% fewer modules to resolve.
    // This is a wire-format change: both devices must run this build or newer,
    // and any pairing must be redone via a freshly scanned QR (same rule as
    // every previous wire-level change — see CHANGELOG.md).
    fun payloadToJson(payload: QrPairingPayload): String {
        val compactUserId = compactUserId(payload.userId) ?: payload.userId
        val onionId = payload.onionAddress.removeSuffix(".onion")
        // `n` is omitted entirely when no relay is configured — a device that doesn't use the
        // relay keeps exactly the QR size it had before v5. Each entry drops the constant
        // "unpruuf-relay:v1:" prefix (~17 chars each, re-added on parse); the address and token
        // stay verbatim, because an address MAY legitimately contain a colon (host:port) and
        // guessing a ".onion" suffix back on would be ambiguous for those.
        val relays = compactRelayList(payload.relayConnectionStrings)
        val relayField = if (relays.isEmpty()) "" else ""","n":"$relays"""
        return """{"v":${payload.version},"u":"$compactUserId","o":"$onionId","p":"${payload.publicKeyBase64}","r":"${payload.rotationFactorBase64}","e":"${payload.appEdition}","k":"${payload.x25519RatchetPublicKeyBase64}"$relayField}"""
    }

    /** Full `unpruuf-relay:v1:<addr>:<token>` strings -> `;`-joined, prefix-stripped form. */
    private fun compactRelayList(relays: List<String>): String =
        relays.map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { it.removePrefix(RELAY_STRING_PREFIX) }
            .take(RelayManager.RELAY_POOL_MAX_SIZE)
            .joinToString(";")

    /** Inverse of [compactRelayList] — re-adds the prefix so the rest of the app only ever sees
     *  canonical connection strings (RelayManager.parseConnectionString rejects anything else). */
    private fun expandRelayList(compact: String): List<String> =
        compact.split(";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { if (it.startsWith(RELAY_STRING_PREFIX)) it else RELAY_STRING_PREFIX + it }
            .filter { RelayManager.parseConnectionString(it) != null }
            .take(RelayManager.RELAY_POOL_MAX_SIZE)

    fun jsonToPayload(json: String): QrPairingPayload? {
        return try {
            val map = parseSimpleJson(json)
            val compactUserId = map["u"] ?: return null
            val onionId = map["o"] ?: return null
            QrPairingPayload(
                version = map["v"]?.toIntOrNull() ?: 1,
                userId = expandUserId(compactUserId) ?: return null,
                onionAddress = "$onionId.onion",
                publicKeyBase64 = map["p"] ?: return null,
                rotationFactorBase64 = map["r"] ?: return null,
                displayName = "",
                appEdition = map["e"] ?: return null,
                x25519RatchetPublicKeyBase64 = map["k"] ?: "",
                // Absent on a pre-v5 QR (and on any device with no relay configured) — an empty
                // list then, which simply means "no relay advertised", exactly as before.
                relayConnectionStrings = map["n"]?.let { expandRelayList(it) } ?: emptyList(),
                timestampMs = 0L
            )
        } catch (e: Exception) {
            null
        }
    }

    // compactUserId/expandUserId/parseSimpleJson moved to QrCodec.kt (package-level, shared
    // with CrossPlatformPairing.kt's relay-based QR) — same functions, no behavior change.
}
