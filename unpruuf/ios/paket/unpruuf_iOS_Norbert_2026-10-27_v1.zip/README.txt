unpruuf iOS-Uebergabe fuer Norbert, 27.10.2026 (vertraulich, Protokolldetails, nicht weitergeben)
Zuerst: 00_START_HIER_IOS_UEBERGABE.md
specs/ Bauanleitungen und Entwuerfe, vectors/ Testvektoren, reference-android/ Android-Quellen und Tests als Referenz.
Enthalten ist nur der OEFFENTLICHE Lizenzschluessel. Kein privater Schluessel, keine Kundenlizenzen, keine Zugangsdaten.
