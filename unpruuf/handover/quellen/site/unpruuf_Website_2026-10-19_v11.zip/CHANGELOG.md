# v11 — 2026-10-19

Farbwelt von Grün auf das Blau aus dem NexonAI-Logo umgestellt.
- Hauptfarbe: Logo-Blau #307098 (Knöpfe, Akzente, Links). Helles Logo-Blau #90c8e8 für Hervorhebungen auf dunklem Grund (zum Beispiel „Ihr eigenes System.“).
- Dunkle Flächen und Texte: dunkles Marineblau statt dunklem Grün. Alle grünen Töne in Flächen, Rahmen und Grautönen sind auf Blau gedreht, Helligkeit unverändert.
- Geändert: styles.css, utilities.css, impressum.html, datenschutz.html, die zwei Vergleichs-SVGs in assets/ und die Browserfarbe (theme-color) in index.html.
- Unverändert: Fotos, Texte, Warnfarbe (Orange), alle Inhalte.
# v10 — 2026-10-19

- Kopfzeile: NexonAI-Logo statt des Schriftzugs „unpruuf.“ oben links (führt wie vorher nach oben).
- Favicon: das NX-Zeichen von NexonAI (favicon.ico, 32/192/512 PNG, Apple-Touch-Icon) auf Startseite, Impressum und Datenschutz. Die Fußzeile bleibt unverändert.

# v9 — 2026-10-17

Nachgezogen auf den Stand vom 17.10.2026:
- Vorfälle-Bereich: „Pakete mit Größe und Ablaufzeit“ ersetzt durch „alle gleich groß, mit Ablaufzeit“ (Karte Signal/WhatsApp und Vergleichstabelle, DE/EN/RO).
- Ghost-Modus: Telefon wird vorübergehend zum Briefkasten mit eigener Adresse; beim Schreiben kein ausgehender Verkehr, nur beim Abholen. Status bleibt „Konzept“.
- Keine Zahlen zu Briefkästen auf der Seite (Regel), sie stehen nur im Whitepaper-Anhang.

# v8 — 2026-10-17

Vorfälle-Bereich kompakt: jeder Fall, die Vergleichstabelle und die Quellen sind Aufklapp-Punkte (zu Beginn geschlossen). Fall-Texte auf je 3 Sätze gekürzt (passiert / mit uns / was bleibt). Kürzere Einleitung, keine Gruppenerklärungen, Kernaussagen nur als Überschriften.

Neuer Bereich „Was passiert ist, und was mit uns passiert wäre“ (#incidents), dreisprachig DE/EN/RO, vor „Einsatzbereiche“.
- 10 Fälle in 4 Gruppen (Telefonnummern und Betreiber, zentrale Server und Updates, Geräte und Protokolle, Menschen und Dokumente), je mit „Was passiert ist“, „Mit uns“ und „Was bleibt“.
- Vergleichstabelle Signal, Threema, Telegram, WhatsApp, unpruuf; drei Kernaussagen; 14 Quellen mit Links.
- Navigation: Eintrag im Ressourcen-Menü und im mobilen Menü.
- Aussagen zu unpruuf sind als eigene, nicht auditierte Analyse gekennzeichnet. Grenzen werden je Fall offen genannt.
- Neue Stile (inc-*) am Ende von styles.css.
- Audit-Roadmap vollständig entfernt: PDF, Download-Kacheln (Ressourcen, Kontaktbereich), Navigationsbezeichnung („FAQ“), Hinweise in Sicherheitskarte 08, Ressourcen-Text und FAQ „Auditiert?“. Die Seite sagt weiter offen: Pilotphase, noch nicht unabhängig auditiert.

# v7 — 2026-10-16

Freigegebenen kurzen Architekturvergleich unter dem Einstieg ergänzt: zwei Bildspalten, drei Plattform-Abhängigkeiten und vier unpruuf-Eigenschaften. Zwei eigene lokal gespeicherte SVG-Illustrationen und lokalisierte Bildbeschreibungen. Neue Inhalte und Links auf Deutsch, Englisch und Rumänisch. Die Illustrationen stellen logische Kommunikationsbereiche dar, keine garantierten dedizierten Server pro Person.

# v6 — 2026-10-16

Navigation und Seitenfolge weiter an der Referenz orientiert. Acht Security-Prinzipien, drei belegte Cyberrisiko-Kennzahlen, drei Einsatzbereiche, FAQ und Abschluss-CTA ergänzt. Neue Inhalte vollständig auf DE/EN/RO. Die Quellen sind direkt im Risikobereich verlinkt; Prozentwerte werden mit ihrer Bezugsgröße gezeigt.

Keine fremden Kundenreferenzen, Zertifizierungen, Audits oder Garantien übernommen. Bestehende 20 Lösungsdetails und Entwicklungskennzeichnungen erhalten. Rechtlicher Hinweis zu externen Links angepasst.

# v5 — 2026-10-16

Neue Seitenführung nach dem Aufbau von Threema: Hero, Hauptprodukte, Architekturprinzipien, Einsatzbereiche, Funktionsweise, Entwicklungsstand, Kontakt und Footer.

Alle 20 Lösungen, drei Sprachen, Statusangaben, PDF und Kontaktfunktionen aus v4 erhalten. Selbst gehostete Assets ausgelagert. Rechtstexte optisch angepasst; Beschreibung des lokalen Entwurfsformulars berichtigt. Offene Unternehmens- und Hostingangaben bleiben offen.
