# CHANGELOG – NexonAI Skill Prompt-Optimierer

## v1 – 30.10.2026
- Neue Skill `prompt-optimizer`: Die Antwort ist nur der optimierte Prompt (ein Codeblock).
- Pflichtabschnitte: Rolle, Ziel, Kontext, Umfang, Format und Lieferung, Regeln, Abnahme, Antwortform, Annahmen und offene Punkte.
- NexonAI-Regeln eingebaut: EN + RO für Kundenmaterial, .bat-Skripte, ZIP mit CHANGELOG, NexonAI-Design, verbotene Aussagen, keine Personenzuweisungen.
- Getestet: ohne Skill kamen Einleitung, Anmerkungen und „DSGVO-konform“; mit Skill nur der Prompt, regelkonform.

## Einbau
- Claude Code (dieses Repo): liegt schon unter `.claude/skills/prompt-optimizer/`, wird automatisch geladen.
- claude.ai: Einstellungen → Fähigkeiten → Skills → Skill hochladen, die Datei `NexonAI_Skill_PromptOptimizer.zip` mit dem Ordner `prompt-optimizer` wählen.
