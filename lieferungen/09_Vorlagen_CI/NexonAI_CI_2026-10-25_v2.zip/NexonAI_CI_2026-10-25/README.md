# NexonAI CI package

Start with `NexonAI_Brand_Guidelines_2026-10.pdf` (9 pages, English).

| Folder | Content |
|---|---|
| 01_Logo | Full logo transparent (200 to 1400 px wide), on white plate (300 to 1200 px, plus JPG), symbol transparent and on white (16 to 1024 px), favicon set, master 1447 px |
| 02_Colors | colors.json, brand-colors.css, palette.gpl (GIMP, Inkscape), contrast.csv |
| 03_Fonts | Open Sans (variable and static TTF, woff2), DejaVu Sans Mono, licences, fonts.css |
| 04_Templates | LinkedIn banner, share image, avatar, email signature |
| 05_Web | brand.css with tokens and base components |

Rules in short: light logo on light backgrounds, the white plate version on dark or busy backgrounds; NexonAI Blue #307098 as the one accent; Open Sans for text, DejaVu Sans Mono for small labels; orange only for pilot and warning labels.

Not included: a vector logo (none exists, redraw needed for large print), Pantone matching, print proofs.
