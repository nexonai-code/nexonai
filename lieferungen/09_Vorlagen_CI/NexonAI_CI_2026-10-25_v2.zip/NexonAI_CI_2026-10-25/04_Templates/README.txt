Templates
- linkedin-banner-1584x396.png, social-share-1200x630.png (link previews), social-avatar-1080.png (profile picture).
- email-signature.html with nexonai-logo-signature.png.
- The banner and share image use the website headline. Change the text, keep fonts, colours and logo as in the guidelines.
