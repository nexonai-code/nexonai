NexonAI fonts
Text: Open Sans (SIL Open Font License 1.1, see OFL-OpenSans.txt). Variable font plus static Regular, Medium, SemiBold, Bold, ExtraBold.
Labels and technical text: DejaVu Sans Mono (free licence, see LICENSE-DejaVu.txt).
Install the static TTFs on every computer that makes NexonAI documents (Word, PowerPoint, Canva). Use the woff2 files and fonts.css on websites.
Fallbacks when a font is missing: Open Sans -> Segoe UI, Arial, sans-serif. DejaVu Sans Mono -> Consolas, monospace.
