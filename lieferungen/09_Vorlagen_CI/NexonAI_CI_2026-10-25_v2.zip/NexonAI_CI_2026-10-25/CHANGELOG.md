# v2 (2026-10-25)

- Markenhandbuch: Namensregel angepasst. Die Hinweisgeber-Lösung heißt "unpruuf Compliance", die Presse-Version "unpruuf Press". Der Hinweis auf eine offene Markenprüfung des früheren Namens entfällt. Sonst unverändert.

# NexonAI CI package v1, 2026-10-19

First version.
- Logo set from the transparent master (1774 x 887 px source, trimmed to 1447 x 525): full logo, white-plate version for dark backgrounds, symbol, favicons.
- Colours taken from the logo and the website (blue theme of 19 October 2026), with RGB, HSL, CMYK (approximate) and WCAG contrast.
- Fonts: Open Sans (OFL) and DejaVu Sans Mono, with licences.
- Templates: LinkedIn banner, share image, avatar, email signature.
- Guidelines PDF, English.
