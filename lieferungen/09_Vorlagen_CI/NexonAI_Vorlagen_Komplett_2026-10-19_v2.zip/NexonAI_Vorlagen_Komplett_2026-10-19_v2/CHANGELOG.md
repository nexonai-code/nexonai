# NexonAI Vorlagen komplett v2 (19.10.2026)

Neu: 03_Proposal_Invoice_EN (Angebot und Rechnung, Englisch, international: VAT ID, Company reg. no., IBAN/BIC, Währung EUR vorbelegt, Reverse-Charge-Hinweis als Platzhalter).
Korrigiert gegenüber v1: In Platzhalterfeldern fehlte bei gemischtem Text das letzte Zeichen (zum Beispiel "Romani" statt "Romania"). Rumänische Fußzeile mit "România".

Ordner:
- 01_Dokument_Brief_DE_EN_RO: Dokument und Brief in drei Sprachen.
- 02_Oferta_Factura_RO: Angebot und Rechnung, Rumänisch.
- 03_Proposal_Invoice_EN: Angebot und Rechnung, Englisch.
- Je Ordner: docx (zum Ausfüllen), dotx (als Word-Vorlage), PDF (Vorschau).
- Schriften: erst installieren (Open Sans, DejaVu Sans Mono).

Offen: CUI, Handelsregister-Nr., USt-IdNr., vollständige Adresse, Bank, IBAN, BIC. Einmal in den dotx-Vorlagen eintragen.
Rechnungen: Layout-Vorlage. In Rumänien gilt RO e-Factura. Für andere Länder Regeln des Kundenlandes prüfen; Reverse-Charge-Text mit dem Steuerberater abstimmen.
