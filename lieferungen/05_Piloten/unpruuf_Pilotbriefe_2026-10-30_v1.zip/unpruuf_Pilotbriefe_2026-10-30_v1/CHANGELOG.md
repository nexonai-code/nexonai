# CHANGELOG – unpruuf_Pilotbriefe_2026-10-30_v1

## v1 – 30.10.2026
- UAB: Pilotvorschlag mit festem Anschlusspreis (EN/RO).
- Alba Carolina TV: Anhang zur Pilotvereinbarung mit Anschlusspreis und Referenz (EN/RO).
