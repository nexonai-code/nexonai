# Alba Carolina TV Pilot

## v2 (25.10.2026)
- Neuer Produktname: Press heißt jetzt "unpruuf Press". Der frühere Name entfällt überall. Leitfaden, Pilotvereinbarung (RO und EN) und Audit-Liste sind neu erzeugt, sonst unverändert.

## v1 (21.10.2026)
1. 01_Leitfaden: Gesprächsleitfaden für das Erstgespräch, Deutsch (für dich) und Rumänisch (zum Mitnehmen). Ziel, Ablauf, neun Fragen, Briefkastenbild in 60 s, Einwände mit ehrlichen Antworten, was wir nicht versprechen, Abschluss.
2. 02_Pilotvereinbarung: Entwurf, Rumänisch (maßgeblich) und Englisch. Drei Monate, kostenlos, Redaktion betreibt eigenen Server, nur niedrige Risiken, Status Pilot ohne Gewähr, Referenz nur mit schriftlicher Freigabe, Kündigung 14 Tage, danach separater Lizenzvertrag.
3. 03_Audit_Liste: 15 Prüfpunkte in drei Prioritäten (A vor der ersten echten Quelle, B vor Pilotende und großen Redaktionen, C danach), Deutsch und Englisch.

Wichtig:
- Die Pilotvereinbarung ist ein Entwurf und muss vor Unterzeichnung von einem Anwalt geprüft werden (Haftung, Datenschutzrolle, Gerichtsstand).
- Offene Felder in [eckigen Klammern]: Firmenname und CUI der Redaktion, eigene CUI, Zeiten, Fristen.
- Rumänischer Text von mir, bitte von Muttersprachler prüfen.
