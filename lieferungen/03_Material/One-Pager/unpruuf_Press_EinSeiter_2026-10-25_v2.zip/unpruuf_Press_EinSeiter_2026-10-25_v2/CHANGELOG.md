# unpruuf Press Ein-Seiten-Beschreibung

## v2 (25.10.2026)
- Neuer Name: Press heißt jetzt "unpruuf Press". Der frühere Produktname entfällt überall. Texte, Titel und Dateinamen sind angepasst (unpruuf_Press_OnePager_EN/RO), sonst ist alles unverändert.

## v1 (21.10.2026)
- Eine A4-Seite, NexonAI-Blau, mit Logo, EN und RO, als PDF und HTML.
- Aufbau: Briefkastenbild (Quelle, Redaktionsserver, Reporter) ohne Zahlen, Voraussetzung eigener Server, drei Schritte, Funktionen mit Stand (PILOT / GEPLANT), was eine Quelle braucht, offene Grenzen.
- Bewusst ohne Technikdetails, ohne Tor, ohne Protokoll, ohne "sicher für Quellen".
- Funktionen "geplant": Tippseite mit QR-Code, ein Briefkasten pro Quelle, Zeitfenster. Noch nicht gebaut.
- Rumänischer Text von mir, bitte von Muttersprachler prüfen.
- .html: Quellen zum Anpassen (Chrome: Drucken als PDF, A4, ohne Ränder).
