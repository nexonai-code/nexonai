# CHANGELOG – unpruuf_Compliance_Ansprache_2026-10-30_v1

## v1 – 30.10.2026
- E-Mail-Folge (Erstmail, Nachfassen Tag 4 und Tag 10), Telefonleitfaden mit 5 Einwänden, LinkedIn (Kontaktanfrage + 4 Beiträge), Ablauf Kontakt bis Vertrag mit Demo-Agenda und Test-Checkliste. EN und RO.
- Zeiten im Ablauf sind Schätzwerte.
