# unpruuf Compliance Video

## v2 (25.10.2026)
- Neuer Name: die Hinweisgeber-Lösung heißt "unpruuf Compliance". Der frühere Produktname entfällt überall, auch in den Bildern der Animation und der Schlusskarte. Videos neu gerendert, Ablauf und Texte sonst unverändert.

## v1 (19.10.2026)
- unpruuf_compliance_en.mp4 / _ro.mp4: 72 s, 1920x1080, 25 fps, ohne Ton, Untertitel eingebrannt.
- unpruuf_compliance_animation.html: dieselbe Animation als eine Datei (im Browser abspielbar, EN/RO über data-lang).
- Ablauf: Problem (Angst, erkannt zu werden), unpruuf Compliance, eigener Server, keine Identitäten, Melden, Abholen (Server sieht nur versiegelte Pakete), Rückfragen anonym, Falllisten mit Status und Termin, nichts bleibt liegen (höchstens 24 h), Schlusskarte.
- Texte folgen dem Skript vom 19.10.2026. Szene 7 sagt "muss seinen Namen nie nennen" (statt "bleibt anonym"). Schlusskarte: "Schematische Darstellung. Nicht auditiert, nicht zertifiziert."
- Rumänischer Text von mir, bitte von Muttersprachler prüfen. Kein Ton, kein Sprecher.
