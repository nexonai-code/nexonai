# unpruuf Architektur-Animation v1 (19.10.2026)

- unpruuf_architecture_en.mp4 / _ro.mp4: 62 s, 1920x1080, 25 fps, ohne Ton, Untertitel eingebrannt.
- unpruuf_architecture_animation.html: interaktive Version (Play/Pause, Szenensprung, EN/RO), eine Datei, NexonAI-Blau.
- Ablauf: zwei Teile (App + eigener Server), Kontakt hat dasselbe, schreiben auf eigenem Server, Abholdaten übergeben, Abholen über Tor, nichts bleibt liegen (höchstens 24 h), Antwort in Gegenrichtung, Schlusskarte "Server sieht versiegelte Pakete".
- Bewusst ohne Zahlen und Protokolldetails. Abspann: "Schematische Darstellung. Nicht auditiert, nicht zertifiziert."
- Rumänischer Text braucht eine Prüfung durch Muttersprachler.
