# Whitepaper Changelog

## v7 (2026-10-25)

- Titelseite jetzt ganz weiß: das Logo (transparente Fassung aus dem CI-Paket, nexonai-logo-1400w.png) steht direkt auf Weiß, dazu eine blaue Linie, der Titel in Navy mit blauem Punkt, Text in Ink, der Statuskasten in Paper mit feiner Linie, zarte hellblaue Kreise als Fläche. Keine dunkle Fläche mehr.
- Hinweis: Das weicht von der CI-Regel "Titelseite Navy mit Logo auf weißer Platte" ab, auf deinen Wunsch. Die Navy-Fassung steht in v6.
- Sonst unverändert gegenüber v6.

## v6 (2026-10-25)

- Farben auf das CI umgestellt: NexonAI Blue #307098 für Linien, Aufzählungszeichen, Links und das Schema, Navy #0F2A3A für Titelseite und Überschriften, Sky #90C8E8 für Hervorhebungen auf dunkel, Mist und Paper für Tabellenköpfe und Flächen, Ink und Graphite für Text, Orange nur für Hinweiskästen (Pilot, Grenzen) und die Zeile "nach höchstens 24 Stunden weg" im Schema. Kein Grün mehr.
- Logo: das Logo auf weißer Platte aus dem CI-Paket (nexonai-logo-plate-1200w.png), unverzerrt und ganz sichtbar, auf der Navy-Titelseite. Innenseiten weiß.
- Version 1.4, 25. Oktober 2026. Beschriftung im Schema (Pfeile) kleiner, damit nichts abgeschnitten wird.
- Produktnamen wie in v5: unpruuf Compliance, unpruuf Press, unpruuf Business.
- Der Inhalt ist sonst unverändert gegenüber v5.

Stand wie immer: nicht auditiert, nicht zertifiziert. Rumänischer Text von mir, Prüfung durch einen Muttersprachler steht aus.
In quelle/build.py die Pfade (Schriftdateien, Logo) auf den eigenen Rechner anpassen.
