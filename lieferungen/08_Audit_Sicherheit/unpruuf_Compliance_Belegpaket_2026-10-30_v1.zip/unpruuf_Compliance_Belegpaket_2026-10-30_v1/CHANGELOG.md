# CHANGELOG – unpruuf_Compliance_Belegpaket_2026-10-30_v1

## v1 – 30.10.2026
- Belegpaket für Datenschutzbeauftragte, EN und RO, je DOCX und PDF: Technikübersicht und Datenlandkarte, TOMs (Software vs. Organisation), vorausgefüllte DSFA-Vorlage, Auftragsverarbeitungsvertrag (Vorlage) mit Nichtzugriffs-Erklärung.
- Stand: getestet, nicht unabhängig auditiert, nicht zertifiziert. Verträge vor Unterschrift von einem Juristen prüfen lassen.
