# CHANGELOG – unpruuf_Compliance_Paket_Preise_2026-10-30_v1

## v1 – 30.10.2026
- Paket „unpruuf Compliance Start“ mit Preisen (50–99, 100–249, 250+ Beschäftigte), 30 Tage gratis testen, Zusatzleistungen. EN und RO.
