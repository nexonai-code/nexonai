# unpruuf Legal pages · CHANGELOG

## v1 · 15.10.2026
- Impressum and Datenschutz rebuilt in EN, RO and DE, one page each with a language switch (remembered as `lp-lang`, same key as the start page).
- Contact: e-mail only, to unpruuf@nexonai.ro (decision of 15.10.2026). The privacy notice no longer names a contact form.
- Newsletter: double opt-in described, consent record kept, unsubscribe by e-mail or link. Sending provider still open.
- Date updated to 15.10.2026. No cookies, no tracking, no analytics (unchanged).

## Open placeholders (highlighted in yellow in both files)
- Street and number of NexonAI Consulting SRL (all three languages, both files)
- Trade register number, CUI, VAT ID (Impressum)
- Hosting provider with location and log retention period (Datenschutz)
- How the newsletter is sent: provider, location, whether opens are measured (Datenschutz)

Not legal advice. Have a lawyer check both pages before publishing.
