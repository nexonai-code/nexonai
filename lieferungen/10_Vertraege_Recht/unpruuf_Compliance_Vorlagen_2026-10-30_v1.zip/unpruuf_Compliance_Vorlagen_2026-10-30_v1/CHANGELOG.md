# CHANGELOG – unpruuf_Compliance_Vorlagen_2026-10-30_v1

## v1 – 30.10.2026
- Angebot, Lizenz- und Servicevertrag, Testvereinbarung 30 Tage, Aushang am Arbeitsplatz, Mitarbeiterinformation (DSGVO Art. 13/14). EN und RO, DOCX und PDF.
- Verträge und Mitarbeiterinformation sind Vorlagen: vor Verwendung von Jurist bzw. Datenschutzbeauftragtem prüfen lassen.
