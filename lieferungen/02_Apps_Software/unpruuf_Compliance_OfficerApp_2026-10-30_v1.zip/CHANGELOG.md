# CHANGELOG – unpruuf Compliance Officer-App

## v1 – 30.10.2026
- Einzelnen Fall löschen: Bestätigung durch Eingabe der Fallnummer, endgültig, Datenbank wird danach verdichtet.
- Löschprotokoll: nur Fallnummer und Zeitpunkt, ohne Inhalt; eigene Ansicht „Jurnal de ștergeri / Deletion log“.
- Fall exportieren: druckbare HTML-Datei (RO, mit ?lang=en Englisch) oder JSON, mit Fristen, Statusverlauf und allen Nachrichten.
- Statusverlauf je Fall wird jetzt gespeichert (ab 30.10.2026).
- 29 automatische Tests grün. Nicht mit einer echten Android-Melde-App getestet.

## Start (Windows)
1. `install.bat` (einmal, braucht Node.js).
2. `start.bat`.
