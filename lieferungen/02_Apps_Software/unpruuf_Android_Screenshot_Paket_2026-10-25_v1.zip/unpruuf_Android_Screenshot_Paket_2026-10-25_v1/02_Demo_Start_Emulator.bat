@echo off
chcp 65001 >nul
title unpruuf Demo-Server (Emulator)
cd /d "%~dp0DemoServer"
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js fehlt. Bitte zuerst 01_Installieren.bat starten.
  pause
  exit /b 1
)
echo.
echo  Demo-Server fuer den Android-Emulator [Compliance]
echo.
node demo.js 
echo.
pause
