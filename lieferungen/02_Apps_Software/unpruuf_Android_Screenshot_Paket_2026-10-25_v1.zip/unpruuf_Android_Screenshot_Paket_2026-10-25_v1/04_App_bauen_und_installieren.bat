@echo off
chcp 65001 >nul
title unpruuf Screenshot-App bauen und installieren
cd /d "%~dp0AndroidApp"
set "SDKDIR=%LOCALAPPDATA%\Android\Sdk"
if not exist "%SDKDIR%\platform-tools\adb.exe" (
  echo  Das Android SDK wurde nicht gefunden [%SDKDIR%].
  echo  Bitte Android Studio installieren und einmal starten [01_Installieren.bat].
  pause
  exit /b 1
)
set "ANDROID_HOME=%SDKDIR%"
set "ANDROID_SDK_ROOT=%SDKDIR%"
if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
> local.properties echo sdk.dir=%SDKDIR:\=\\%
echo.
echo  Die Screenshot-Variante [whistleblowerDemo] wird gebaut. Beim ersten Mal laedt Gradle viel
echo  herunter und braucht einige Minuten. Internet muss an sein.
echo.
call gradlew.bat assembleWhistleblowerDemo
if errorlevel 1 (
  echo.
  echo  Der Build ist fehlgeschlagen. Bitte die Meldung oben an Claude schicken.
  pause
  exit /b 1
)
set "APK=%~dp0AndroidApp\app\build\outputs\apk\whistleblower\demo\app-whistleblower-demo.apk"
if not exist "%APK%" (
  echo  Die APK wurde nicht gefunden: %APK%
  pause
  exit /b 1
)
set "ADB=%SDKDIR%\platform-tools\adb.exe"
"%ADB%" start-server >nul 2>nul
echo.
echo  Installiere auf das laufende Geraet [Emulator oder Handy per USB] ...
"%ADB%" install -r "%APK%"
if errorlevel 1 (
  echo.
  echo  Die Installation ging nicht. Laeuft ein Emulator, oder ist das Handy per USB verbunden [USB-Debugging an]?
  pause
  exit /b 1
)
"%ADB%" shell am start -n com.nexonai.unpruuf.whistleblower.demo/com.nexonai.unpruuf.MainActivity
echo.
echo  Fertig. Die App ist gestartet.
pause
