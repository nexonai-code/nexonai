# Changelog

## v1 (2026-10-25)
- Android-Studio-Projekt (Stand Branch android, App 1.17) mit zusätzlicher Variante `whistleblowerDemo` (und `pressDemo`) für Screenshots: ohne Bildschirmsperre, Relay `host:port` direkt, eigene Kennung `.demo`, nur arm64-v8a und x86_64.
- DemoServer: Relay und Officer-Dashboard (Stand Branch ccr-9a899f8d-xrqsp0, mit den neuen Produktnamen), Start per .bat für Emulator, Handy und Press.
- Skripte: Installation, Demo-Start, Demo-Reset, Screenshots per adb, App bauen und installieren.
- Geprüft: Demo-Variante baut (`assembleWhistleblowerDemo`), Demo-Server startet in Emulator- und Handy-Modus, Dashboard antwortet, Officer-Code wird erzeugt.
- Der frühere Produktname steht im Android-Quelltext nur noch in drei Kommentaren; sie sind in diesem Paket angepasst (der Branch android selbst ist nicht verändert).
- Nicht geprüft: Bedienung der App im Emulator, `.bat`-Dateien unter Windows.
