@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title unpruuf Screenshot machen
cd /d "%~dp0"
set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not exist "%ADB%" set "ADB=adb"
"%ADB%" version >nul 2>nul
if errorlevel 1 (
  echo  adb wurde nicht gefunden. Bitte Android Studio installieren [01_Installieren.bat].
  pause
  exit /b 1
)
"%ADB%" start-server >nul 2>nul
if not exist "%~dp0Screenshots" mkdir "%~dp0Screenshots"
set /a N=0
echo.
echo  Screenshots der App, direkt vom Emulator oder Handy.
echo  Die App auf den gewuenschten Bildschirm stellen, dann hier:
echo    Enter = Bild mit Nummer aufnehmen
echo    Name + Enter = Bild mit diesem Namen aufnehmen [ohne Leerzeichen]
echo    Q + Enter = Ende
echo  Die Bilder liegen im Ordner Screenshots.
echo.
:schleife
set "NAME="
set /p NAME= Name (Enter = Nummer, Q = Ende): 
if /i "!NAME!"=="Q" goto ende
if "!NAME!"=="" (
  set /a N+=1
  set "NUM=0!N!"
  set "NAME=bild_!NUM:~-2!"
)
"%ADB%" exec-out screencap -p > "%~dp0Screenshots\!NAME!.png"
if errorlevel 1 (
  echo  Das ging nicht. Laeuft ein Emulator oder ist das Handy per USB verbunden [USB-Debugging an]?
) else (
  for %%F in ("%~dp0Screenshots\!NAME!.png") do echo  Gespeichert: Screenshots\!NAME!.png ^(%%~zF Bytes^)
)
goto schleife
:ende
echo.
echo  Fertig. Ordner Screenshots.
pause
