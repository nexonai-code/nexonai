@echo off
chcp 65001 >nul
title unpruuf Screenshot-Paket: Installation
cd /d "%~dp0"
echo.
echo  unpruuf Screenshot-Paket: Installation [einmalig]
echo  --------------------------------------------------
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js fehlt. Wird mit winget installiert ...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
)
where node >nul 2>nul
if errorlevel 1 goto neustart
echo.
echo  [1/3] Relay [Postfach-Server fuer den Test] wird vorbereitet ...
cd /d "%~dp0DemoServer\relay"
call npm install
if errorlevel 1 goto fehler
call npm run build
if errorlevel 1 goto fehler
echo.
echo  [2/3] Officer-Dashboard wird vorbereitet ...
cd /d "%~dp0DemoServer\officer-app"
call npm install
if errorlevel 1 goto fehler
call npm run build
if errorlevel 1 goto fehler
cd /d "%~dp0"
echo.
echo  [3/3] Android Studio pruefen ...
set "STUDIO=%ProgramFiles%\Android\Android Studio\bin\studio64.exe"
if exist "%STUDIO%" (
  echo  Android Studio ist installiert.
) else (
  echo  Android Studio wurde nicht gefunden.
  choice /c JN /m "  Jetzt mit winget installieren (ca. 1 GB)? [J]a / [N]ein"
  if errorlevel 2 (
    echo  Dann bitte selbst von https://developer.android.com/studio laden und installieren.
  ) else (
    winget install -e --id Google.AndroidStudio --accept-source-agreements --accept-package-agreements
    echo  Android Studio einmal starten und die Einrichtung [Standard] durchlaufen lassen. Das laedt das Android SDK.
  )
)
echo.
echo  Fertig. Weiter mit LIESMICH.md [Schritt 2].
pause
exit /b 0
:neustart
echo.
echo  Es wurde gerade etwas installiert. Bitte dieses Fenster schliessen und 01_Installieren.bat noch einmal starten.
pause
exit /b 1
:fehler
echo.
echo  Bei der Installation ist ein Fehler aufgetreten. Bitte die Meldung oben an Claude schicken.
pause
exit /b 1
