@echo off
chcp 65001 >nul
title unpruuf Demo-Server zuruecksetzen (Emulator)
cd /d "%~dp0DemoServer"
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js fehlt. Bitte zuerst 01_Installieren.bat starten.
  pause
  exit /b 1
)
echo.
echo  Alte Demo-Faelle loeschen und neu starten [Emulator]
echo.
node demo.js --reset
echo.
pause
