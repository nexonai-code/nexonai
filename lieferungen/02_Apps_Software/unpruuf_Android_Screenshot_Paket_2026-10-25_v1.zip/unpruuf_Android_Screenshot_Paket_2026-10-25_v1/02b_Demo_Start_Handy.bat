@echo off
chcp 65001 >nul
title unpruuf Demo-Server (Handy)
cd /d "%~dp0DemoServer"
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js fehlt. Bitte zuerst 01_Installieren.bat starten.
  pause
  exit /b 1
)
echo.
echo  Demo-Server fuer ein echtes Handy im selben WLAN [Compliance]
echo.
node demo.js --phone
echo.
pause
