/* Demo server for the app screenshots: starts a relay and the officer dashboard on this PC and prints / copies the officer code.
   node demo.js              emulator mode (the emulator reaches the PC as 10.0.2.2)
   node demo.js --phone      phone mode (a phone in the same Wi-Fi reaches the PC by its network address)
   node demo.js --press      press edition of the dashboard (port 3001) instead of compliance
   node demo.js --reset      delete the demo data of this mode first (new relay token, no old cases)
   Test setup only: the relay is reached without Tor. Never use it for real reports. */
"use strict";
const fs = require("fs"), path = require("path"), os = require("os"), http = require("http"), { spawn, spawnSync } = require("child_process");
const has = (f) => process.argv.includes(f);
const MODE = has("--phone") ? "phone" : "emulator", PRESS = has("--press");
const ROOT = __dirname, DATA = path.join(ROOT, "demo-data", MODE + (PRESS ? "-press" : ""));
const RELAY_PORT = 8787, DASH_PORT = PRESS ? 3001 : 3000, PASSWORD = "demo-passwort";
const RELAY_JS = path.join(ROOT, "relay", "dist", "index.js"), OFFICER_JS = path.join(ROOT, "officer-app", "dist", "index.js");
const log = (s) => console.log(s);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function lanAddress() {
  if (process.env.DEMO_HOST) return process.env.DEMO_HOST;
  const found = [];
  for (const list of Object.values(os.networkInterfaces())) for (const n of list || []) {
    if (n.family === "IPv4" && !n.internal && /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(n.address)) found.push(n.address);
  }
  return found[0] || null;
}
function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => { let b = ""; res.on("data", (d) => (b += d)); res.on("end", () => { try { resolve(JSON.parse(b)); } catch (e) { reject(e); } }); }).on("error", reject);
  });
}
async function waitFor(fn, what, seconds) {
  const end = Date.now() + seconds * 1000;
  for (;;) { try { const v = await fn(); if (v) return v; } catch (e) { /* not yet */ } if (Date.now() > end) throw new Error(what + " did not start within " + seconds + " s"); await sleep(400); }
}
function toClipboard(text) {
  try {
    const cmd = process.platform === "win32" ? ["clip", []] : process.platform === "darwin" ? ["pbcopy", []] : null;
    if (!cmd) return false;
    const r = spawnSync(cmd[0], cmd[1], { input: text, shell: process.platform === "win32" });
    return r.status === 0;
  } catch (e) { return false; }
}

async function main() {
  for (const f of [RELAY_JS, OFFICER_JS]) if (!fs.existsSync(f)) { log("\n  Es fehlt " + path.relative(ROOT, f) + ". Bitte zuerst 01_Installieren.bat starten.\n"); process.exit(1); }
  if (has("--reset")) { fs.rmSync(DATA, { recursive: true, force: true }); log("  Demo-Daten gelöscht: " + DATA); }
  const relayData = path.join(DATA, "relay"), officerData = path.join(DATA, "officer");
  fs.mkdirSync(relayData, { recursive: true }); fs.mkdirSync(officerData, { recursive: true });

  let host;
  if (MODE === "phone") { host = lanAddress(); if (!host) { log("\n  Keine Netzwerkadresse gefunden. Ist der PC im WLAN? Notfalls: set DEMO_HOST=<Adresse des PCs> und noch einmal starten.\n"); process.exit(1); } }
  else host = "10.0.2.2";

  const kids = [];
  const stop = () => { for (const k of kids) { try { k.kill(); } catch (e) { /* gone */ } } process.exit(0); };
  process.on("SIGINT", stop); process.on("SIGTERM", stop);

  log("\n  [1/3] Relay wird gestartet ...");
  const relay = spawn(process.execPath, [RELAY_JS], { cwd: path.join(ROOT, "relay"), env: { ...process.env, PORT: String(RELAY_PORT), RELAY_BIND_HOST: "0.0.0.0", RELAY_DATA_DIR: relayData }, stdio: ["ignore", "pipe", "pipe"] });
  kids.push(relay);
  relay.stdout.on("data", () => {}); relay.stderr.on("data", (d) => process.stderr.write("  [relay] " + d));
  relay.on("exit", (c) => { log("\n  Der Relay wurde beendet (Code " + c + "). Läuft schon ein anderes Programm auf Port " + RELAY_PORT + "?"); stop(); });
  await waitFor(async () => (await getJson("http://127.0.0.1:" + RELAY_PORT + "/health")).ok, "Relay", 30);
  const idFile = path.join(relayData, "relay-identity.json");
  const token = (await waitFor(async () => JSON.parse(fs.readFileSync(idFile, "utf8")), "Relay-Zugangsdaten", 10)).authToken;
  const connection = "unpruuf-relay:v1:" + host + ":" + RELAY_PORT + ":" + token;

  log("  [2/3] Officer-Dashboard wird gestartet ...");
  const env = { ...process.env, RELAY_CONNECTION_STRING: connection, RELAY_REACHABLE_BASE_URL: "http://127.0.0.1:" + RELAY_PORT, OFFICER_PASSWORD: PASSWORD, OFFICER_DATA_DIR: officerData, PORT: String(DASH_PORT), POLL_INTERVAL_MS: "1500", OFFICER_OPEN_BROWSER: "1" };
  if (PRESS) env.OFFICER_EDITION = "press";
  const officer = spawn(process.execPath, [OFFICER_JS], { cwd: path.join(ROOT, "officer-app"), env, stdio: ["ignore", "pipe", "pipe"] });
  kids.push(officer);
  officer.stdout.on("data", () => {}); officer.stderr.on("data", (d) => process.stderr.write("  [officer] " + d));
  officer.on("exit", (c) => { log("\n  Das Officer-Dashboard wurde beendet (Code " + c + "). Läuft schon ein anderes Programm auf Port " + DASH_PORT + "?"); stop(); });
  const me = await waitFor(() => getJson("http://127.0.0.1:" + DASH_PORT + "/api/me"), "Officer-Dashboard", 40);
  const code = me.pairingCode;
  fs.writeFileSync(path.join(ROOT, "..", "officer-code.txt"), code);
  const copied = toClipboard(code);

  log("  [3/3] Fertig.\n");
  log("  ==============================================================================");
  log("   Demo-Server läuft (" + (MODE === "phone" ? "Handy-Modus, PC-Adresse " + host : "Emulator-Modus, Relay für die App: 10.0.2.2") + ")");
  log("   Dashboard:  http://localhost:" + DASH_PORT + "   (öffnet sich von selbst)");
  log("   Officer-Code: " + (copied ? "liegt in der Zwischenablage" : "steht in der Datei officer-code.txt (neben dieser Anleitung)"));
  log("   In der App: Code einfügen (lang auf das Feld tippen, Einfügen), dann \"Add from pasted code\".");
  if (MODE === "phone") log("   Handy-Modus: Handy und PC im selben WLAN. Fragt Windows nach der Firewall: \"Zugriff zulassen\".");
  log("   Dieses Fenster offen lassen. Beenden mit Strg+C.");
  log("  ==============================================================================\n");
  if (!copied) log("  Code:\n  " + code + "\n");
}
main().catch((e) => { console.error("\n  Fehler: " + e.message + "\n"); process.exit(1); });
