# unpruuf Compliance: Paket für echte Android-App-Screenshots

Mit diesem Paket machst du auf deinem Windows-PC echte Bilder der Android-App (Melder-Seite von unpruuf Compliance), von der Einrichtung bis zur Antwort des Officers. Es enthält:

- `AndroidApp/`: das Android-Studio-Projekt (Stand Branch `android`), mit einer zusätzlichen Variante **whistleblowerDemo** nur für Screenshots.
- `DemoServer/`: ein Test-Relay und das Officer-Dashboard, die auf deinem PC laufen und mit der App sprechen.
- `.bat`-Dateien zum Installieren, Starten und für Screenshots, dazu `CHECKLISTE_Screenshots.md` (welche Bilder, in welcher Reihenfolge).

## Wichtig vorab (ehrlicher Stand)
- **Die Demo-Variante ist nur für Screenshots.** Sie hat die Bildschirmsperre der App ausgeschaltet (sonst kommen schwarze Bilder) und spricht den Test-Relay auf deinem PC **direkt, ohne Tor** an. Sie nie an Kunden geben und nie für echte Meldungen benutzen. Die echte App aus dem Repository bleibt unverändert (mit Sperre, immer über Tor).
- Tor selbst startet in der App trotzdem und braucht beim ersten Mal 1 bis 3 Minuten und Internet. Solange es nicht verbunden ist, sendet die App nicht.
- **Ich konnte die App hier nicht im Emulator bedienen** (kein schneller Emulator in meiner Umgebung). Getestet habe ich: Die Demo-Variante lässt sich bauen (Android SDK 34, `app-whistleblower-demo.apk`), und der Demo-Server startet, erzeugt den Officer-Code und das Dashboard antwortet. Den Weg in der App selbst (Einrichtung, Code einfügen, Fall anlegen) konnte ich nicht durchspielen. Wenn etwas hakt, schick mir die Meldung oder ein Foto vom Bildschirm.
- Die `.bat`-Dateien sind auf Windows ungetestet.
- Alles, was du siehst, sind Testdaten. Die Bilder bitte als "Demo-Build, Testdaten" kennzeichnen.

## Schritt 1: einmal vorbereiten
1. `01_Installieren.bat` doppelklicken. Es installiert Node.js (falls nötig), bereitet Relay und Dashboard vor und fragt, ob Android Studio installiert werden soll (ca. 1 GB). Wenn es sagt, dass etwas neu installiert wurde: Fenster schließen und die Datei noch einmal starten.
2. Android Studio einmal öffnen und die Standard-Einrichtung durchlaufen lassen (lädt das Android SDK).

## Schritt 2: Gerät bereitstellen
**Emulator (empfohlen):** Android Studio, Menü *More Actions / Tools → Device Manager → Create Virtual Device*. Gerät "Pixel 7", System-Image **API 34, "Google APIs" (nicht "Google Play"), x86_64**, Finish, dann starten. Windows braucht dafür eine eingeschaltete Virtualisierung (im BIOS "Virtualization" und in Windows "Windows-Hypervisorplattform"). Ohne sie ist der Emulator unbrauchbar langsam.

**Oder ein echtes Handy:** Entwickleroptionen einschalten, USB-Debugging an, per USB anschließen und am Handy die Anfrage bestätigen. Dann in Schritt 4 `02b_Demo_Start_Handy.bat` nehmen (Handy und PC im selben WLAN).

## Schritt 3: die Demo-App installieren (ein Weg reicht)
**Weg A, Android Studio:** *File → Open* und den Ordner `AndroidApp` wählen. Warten, bis Gradle fertig ist (erstes Mal einige Minuten). Links unten *Build Variants* öffnen und für `app` die Variante **whistleblowerDemo** wählen. Oben das Gerät wählen und auf den grünen Pfeil (Run) klicken.

**Weg B, ohne Android Studio bedienen:** Emulator oder Handy läuft, dann `04_App_bauen_und_installieren.bat`. Es baut `whistleblowerDemo`, installiert und startet die App.

**Weg C, fertige APK:** Sie liegt in einem zweiten ZIP (`unpruuf_Android_Demo_APK_…zip`, ca. 46 MB). Emulator laufen lassen und die APK auf das Emulator-Fenster ziehen. Sie ist aus demselben Quelltext gebaut wie Weg A und B.

Die Demo-App erscheint neben einer eventuellen echten App (eigene Kennung `…whistleblower.demo`).

## Schritt 4: Demo-Server starten
- Emulator: `02_Demo_Start_Emulator.bat`
- Handy: `02b_Demo_Start_Handy.bat` (Windows fragt nach der Firewall: Zugriff zulassen)
- Press-Version (Journalisten): `02c_Demo_Start_Press_Emulator.bat`
- Alte Testfälle löschen: `02z_Demo_Zuruecksetzen_Emulator.bat`

Das Fenster offen lassen. Das Dashboard öffnet sich im Browser. **Der Officer-Code liegt in der Zwischenablage** und in der Datei `officer-code.txt`.

## Schritt 5: in der App
1. App starten. Beim ersten Start kommen Einrichtungsfragen (PIN und Notfall-PIN, evtl. Berechtigungen). Normal beantworten.
2. Auf dem Bildschirm zum Hinzufügen der Organisation ("Paste the officer's code" / rumänisch entsprechend): in das Feld lang tippen, **Einfügen**, dann "Add from pasted code". Im Emulator wird die Zwischenablage des PCs automatisch übernommen. Wenn nicht: den Code aus `officer-code.txt` per Mail oder Notiz aufs Handy schicken und dort kopieren.
3. Neuen Fall anlegen (Knopf "New case"), Meldung schreiben, senden. Die Meldung erscheint nach einigen Sekunden im Dashboard, die App zeigt dann die Fallnummer.
4. Im Dashboard antworten und den Status ändern (siehe Checkliste), jeweils wieder die App ansehen.

## Schritt 6: Bilder machen
- `03_Screenshot.bat`: Enter drückt jeweils ein Bild (oder Name eingeben). Die Bilder landen im Ordner `Screenshots`.
- Oder im Emulator die Kamera-Taste in der Seitenleiste.
- Die Reihenfolge steht in `CHECKLISTE_Screenshots.md`. Am Ende den Ordner `Screenshots` zippen und mir schicken. Ich baue sie in den Film, die Artefakte und die Website ein.

## Wenn etwas nicht klappt
| Problem | Was tun |
|---|---|
| Screenshots sind schwarz | Falsche Variante installiert. In Android Studio muss **whistleblowerDemo** gewählt sein, nicht debug oder release. |
| App sendet nicht, bleibt bei "Report on its way" | Tor ist noch nicht verbunden (1 bis 3 Minuten, braucht Internet) oder der Demo-Server läuft nicht. Dashboard offen? Im Handy-Modus: gleiches WLAN, Firewall erlaubt? |
| Emulator extrem langsam | Virtualisierung ist aus (BIOS und Windows-Hypervisorplattform), oder das System-Image ist nicht x86_64. |
| App meldet "Gerät nicht erlaubt" o. Ä. | Emulator mit "Google APIs" (nicht "Google Play") und ohne Root verwenden. Sonst Meldung an mich schicken. |
| Build in Android Studio schlägt fehl | Meldung vollständig an mich schicken. Android Studio ab Hedgehog (2023.1) verwenden, JDK 17 ist eingebaut. |
| `03_Screenshot.bat` findet kein Gerät | Emulator läuft? Oder Handy per USB, Debugging an und die Anfrage am Handy bestätigt. |

## Was geändert wurde (für den Quelltext-Vergleich)
Nur diese vier Stellen, alle durch `BuildConfig.DEMO_SCREENSHOTS` geschützt, das nur in der Variante `demo` wahr ist:
1. `app/build.gradle.kts`: neue Variante `demo` (wie debug, Kennung `.demo`, nur die Prozessoren arm64-v8a und x86_64).
2. `MainActivity.kt`: Bildschirmsperre (FLAG_SECURE) nur, wenn nicht Demo.
3. `ui/SecureDialog.kt`: Dialoge ohne Sperre nur in der Demo.
4. `domain/network/RelayClient.kt`: Relay-Adresse in der Form `host:port` wird in der Demo direkt angesprochen, sonst immer über Tor.
