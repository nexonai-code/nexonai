@echo off
chcp 65001 >nul
title unpruuf Demo-Server (Press, Emulator)
cd /d "%~dp0DemoServer"
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js fehlt. Bitte zuerst 01_Installieren.bat starten.
  pause
  exit /b 1
)
echo.
echo  Demo-Server fuer den Android-Emulator [Press-Version]
echo.
node demo.js --press
echo.
pause
