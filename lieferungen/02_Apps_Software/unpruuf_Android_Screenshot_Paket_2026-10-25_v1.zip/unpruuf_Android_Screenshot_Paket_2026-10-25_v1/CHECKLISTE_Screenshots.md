# Checkliste: welche Bilder, in welcher Reihenfolge

Die Namen der Knöpfe stammen aus dem Quelltext (englisch; in der rumänischen Fassung entsprechend). Wenn ein Bildschirm anders aussieht, nimm ihn trotzdem. Dashboard-Bilder habe ich schon (Testlauf vom 25.10.); hier geht es nur um die App.

Vorher: Demo-Server läuft (Schritt 4), Demo-App ist installiert. Benenne die Bilder mit `03_Screenshot.bat` gleich passend.

| Nr. | Name | Was auf dem Bildschirm sein soll | Wie du dort hinkommst |
|---|---|---|---|
| 1 | 01_pin_einrichten | PIN einrichten ("Set up PIN") | erster Start; keine echte PIN zeigen, Testwerte nehmen |
| 2 | 02_start_ohne_organisation | Startbildschirm vor dem Hinzufügen | nach der PIN |
| 3 | 03_code_einfuegen | Feld "Paste the officer's code" und Knopf "Add from pasted code" | Code in das Feld einfügen, noch nicht senden |
| 4 | 04_meine_faelle_leer | "My cases" mit "No case yet." | nach "Add from pasted code" |
| 5 | 05_neuer_fall | Fall anlegen ("New case") | Knopf "New case" |
| 6 | 06_nachricht_geschrieben | Meldungstext im Eingabefeld, vor dem Senden | Text schreiben, nicht senden |
| 7 | 07_fall_unterwegs | "Report on its way" | direkt nach dem Senden |
| 8 | 08_fall_bestaetigt | Fallnummer und Status "Received and confirmed" | wenige Sekunden später; Demo-Server und Tor müssen laufen |
| 9 | 09_fall_in_pruefung | Status "Under review" | im Dashboard den Status auf "În lucru" (in Arbeit) stellen |
| 10 | 10_nachrichten_antwort | Reiter "Messages" mit der Antwort des Officers | im Dashboard eine Rückfrage senden |
| 11 | 11_antwort_des_melders | die eigene Antwort in der Unterhaltung | in der App antworten |
| 12 | 12_fall_geschlossen | Status "Closed" | im Dashboard den Fall schließen |
| 13 | 13_faelle_liste | Liste mit 2 bis 3 Fällen | weitere Fälle über "New case" anlegen |
| 14 | 14_einstellungen | Einstellungen | Menü oben rechts: "Settings" |
| 15 | 15_fall_entfernen | Hinweisfenster "Remove case from this phone?" | Fall öffnen, Menü, "Remove case from this phone" (nicht bestätigen) |

Tipps:
- Für Kundenmaterial in Rumänisch und Englisch: Das Handy einmal auf Rumänisch und einmal auf Englisch stellen und die Bilder 3 bis 12 wiederholen.
- Für die Press-Version: `02c_Demo_Start_Press_Emulator.bat` und die Variante **pressDemo** bauen. Die Checkliste ist dieselbe, nur die Wörter ändern sich.
- Keine echten Namen, Nummern oder Codes in den Bildern. Der Officer-Code in Bild 3 ist ein Testcode, trotzdem das Feld nach dem Bild leeren.
