# unpruuf Guest Lockers v2, 2026-10-18

Alle Dateien mit Repo-Pfaden (über das Repo legen). Ergänzt v1.

- Server: Slot-Bereiche im Token für den Server mit 250 virtuellen Nodes und 100 Slots (`src/guest/guestScope.ts`, `depositAuth.ts`): leerer Bereich scheitert geschlossen, Einzahlung außerhalb der freigegebenen Slots wird mit 403 abgelehnt. 37 Server-Tests bestanden.
- Android: `GuestScope.kt`, `GuestInvite.kt`, Einladen-Bildschirm (`GuestInviteScreen`, `GuestInviteViewModel`), Navigation, Knopf im Business-Kopplungsbildschirm (nur Pro). 15 JVM-Tests bestanden.
- Testvektor `slot-scope` ergänzt (Server, Android, iOS müssen ihn reproduzieren).
- Spec Abschnitt 15 und `guest-grants/FORMAT.md` aktualisiert.

Nicht geprüft: `GuestInviteScreen.kt`, `GuestInviteViewModel.kt`, `AppNavigation.kt`, `QrPairScreen.kt`, `NodeMeshClient.kt`, `NodeMeshPairing.kt` wurden nicht kompiliert (kein Android SDK hier).
Nicht gemacht: Einbau in den aktuellen 250er-Server (liegt nicht im Repo), Import und Ablage der Gast-Tokens in der Client-App, automatische Erneuerung, Control, Beleg-Skripte.
