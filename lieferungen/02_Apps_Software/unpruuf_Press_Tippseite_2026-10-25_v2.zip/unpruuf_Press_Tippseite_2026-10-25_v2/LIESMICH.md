# unpruuf Press, Tippseiten-Baukasten

Doppelklick auf `unpruuf_Press_Tippseiten-Baukasten.html`. Läuft im Browser, ohne Installation, ohne Internet, sendet nichts.

1. Name der Redaktion eintragen, Sprache wählen (Română, English oder beide), Farbe und Logo nach Wunsch.
2. Den allgemeinen Kontaktcode einfügen (zeigt das Programm der Redaktion an). Für jede Recherche oder jeden Artikel "+ Code für ein Thema", Titel und Code einfügen.
3. Rechts die Vorschau prüfen. "Tippseite herunterladen" ergibt eine einzelne Datei zum Hochladen auf die Website. "Druckkarten herunterladen" im Browser öffnen und als PDF drucken (A4, zwei Karten nebeneinander, Schnittlinien).
4. "QR als SVG" speichert jeden QR-Code einzeln (für Artikel, Plakat, Visitenkarte).
5. "Projekt speichern" legt die Einstellungen als Datei ab, damit man später etwas ändern kann.

Vor der Veröffentlichung prüfen:
- Mit einem echten Telefon und der unpruuf-App jeden QR-Code scannen, auch aus Papier und vom Bildschirm.
- Die Option "Code kopieren und QR-Bild speichern" nur einschalten, wenn die App-Version den Import wirklich kann.
- Texte auf der Seite (Pilot, nicht auditiert, 24 Stunden) nicht entfernen.

Der Ordner Beispiel enthält nur Ansichten mit Platzhalter-Codes ("BEISPIEL-CODE-NICHT-ECHT"). Diese QR-Codes nie veröffentlichen.
