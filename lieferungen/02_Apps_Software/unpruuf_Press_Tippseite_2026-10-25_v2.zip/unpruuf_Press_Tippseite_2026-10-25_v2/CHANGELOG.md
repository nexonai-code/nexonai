# unpruuf Press Tippseite

## v2 (25.10.2026)
- Neuer Name: Press heißt jetzt "unpruuf Press". Der frühere Produktname entfällt überall. Baukasten, Beispiel-Tippseite und LIESMICH sind angepasst, die Baukasten-Datei heißt jetzt unpruuf_Press_Tippseiten-Baukasten.html. Die erzeugten Tippseiten nennen "unpruuf Press" im Fußtext. Sonst unverändert (Test des Baukastens läuft ohne Fehler).

## v1 (21.10.2026)
- Baukasten als eine HTML-Datei (Oberfläche DE, EN, RO). Erzeugt: Tippseite (RO, EN oder beide, mit Umschalter), Druckkarten (A4, zwei Spalten), QR einzeln als SVG, Projekt speichern und laden.
- Die Tippseite ist eine einzelne Datei ohne Fremdanfragen, ohne Zählpixel, ohne externe Skripte, mit strenger Inhaltsrichtlinie, ohne Suchmaschinen-Indexierung.
- Der QR-Code kodiert den eingefügten Kontaktcode unverändert (UTF-8, Fehlerkorrektur M). Alle erzeugten Codes wurden maschinell zurückgelesen und stimmen.
- Seitentext: so funktioniert es, Antworten höchstens 24 Stunden aufbewahrt, ehrlicher Block "Gut zu wissen" (Pilot, nicht auditiert, kein Schutz bei infiziertem oder beschlagnahmtem Gerät).
- QR-Bibliothek: qrcode-generator 2.0.4 (MIT), eingebettet.

Offen:
- Nicht getestet mit der echten unpruuf-App und der Press-Oberfläche: Format des Kontaktcodes und Import per Scan, Kopieren oder Bild.
- Pro Thema ein eigenes Fach setzt voraus, dass die Press-Oberfläche je Recherche einen eigenen Code erzeugt (geplant, nicht gebaut).
- Rumänischer Text von mir, bitte von Muttersprachler prüfen.
