# safeline Press: Code pro Recherche v1 (21.10.2026)

Branch ccr-9a899f8d-xrqsp0, Commit c6b1d95 (der Ordner `officer-app` wurde unverändert vom Branch `android` übernommen, Commit f395c38).

Neu in der Officer-App (Press-Ausgabe):
- Recherchen mit eigenem Code: eigene Schlüssel und eigener Briefkasten je Recherche (src/officer/recherchen.ts). Die Melde-Apps brauchen keine Änderung.
- Hinweise werden der Recherche zugeordnet (neue Spalte `recherche_id`, neue Tabelle `recherchen`, verschlüsselt wie alle Geheimnisse). Alte Datenbanken werden beim Start ergänzt.
- Poll-Schleife fragt den Briefkasten des allgemeinen Codes und jeder aktiven Recherche ab; Antworten, Statusmeldungen und Bestätigungen laufen mit den Schlüsseln der jeweiligen Recherche.
- Anhalten und Fortsetzen eines Codes; Umbenennen; kein Löschen (die Schlüssel werden für bereits empfangene Hinweise gebraucht).
- Oberfläche (RO und EN): Menüpunkt Investigații, Karten mit QR, Kopieren, Groß anzeigen, PNG, Umbenennen, Anhalten; Etikett der Recherche in der Hinweis-Liste und in den Details; Suche findet auch den Namen; Export der Code-Liste.
- API (nur Press): GET/POST /api/recherchen, POST /api/recherchen/:id, GET /api/recherchen/export. In der Compliance-Ausgabe antworten sie mit 404.
- Fehler behoben, der schon im alten Code war: In der Hinweis-Liste stand statt "fără categorie" der Rohtext `${t("uncategorised_l")}`.
- Tests: 8 neue, ein bestehender Test angepasst (neues Feld in CaseRow). Alle 23 bestehen.

Tippseiten-Baukasten (v2): nimmt die exportierte Code-Liste direkt auf.

Offen: Test mit echter Press-App auf einem Telefon; Zusammenführung der Branches (officer-app liegt jetzt auch auf diesem Branch).
