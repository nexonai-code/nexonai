# safeline Press: Code pro Recherche

## Starten
1. In `officer-app` doppelklicken: `install.bat` (nur beim ersten Mal), dann `start-press.bat`. Es fragt nach dem Relay-Code und dem Passwort und öffnet `http://localhost:3001`.
2. Links im Menü: **Investigații** (Englisch: Researches).

## Code pro Recherche
- Namen eintragen, "Creează cod" drücken. Es erscheint ein QR-Code mit eigenem Schlüssel und eigenem Briefkasten.
- Pro Code: Code kopieren, groß anzeigen, QR als PNG laden, umbenennen, anhalten und wieder starten.
- Ein Hinweis, der über so einen Code kommt, steht in der Liste mit dem Namen der Recherche. Der allgemeine Code ("Codul tău") bleibt wie bisher.
- "Descarcă lista de coduri" erzeugt eine Textdatei mit einer Zeile je Code (Titel | Code). Die Datei lässt sich im **Tippseiten-Baukasten** (Ordner `Tippseiten-Baukasten`, Doppelklick) unter "Liste aus dem Press-Programm einfügen" übernehmen. Daraus entstehen Tippseite, Druckkarten und einzelne QR-Dateien.

## Geprüft und nicht geprüft
- Geprüft: 23 automatische Tests bestehen (8 neue). Sie spielen den ganzen Weg durch: Code erzeugen, Quelle meldet sich, Hinweis wird der Recherche zugeordnet, Eingangsbestätigung, Antwort, Anhalten und Fortsetzen. Die QR-Codes der Liste wurden aus dem Baukasten wieder ausgelesen und stimmen mit den Codes des Programms überein.
- Nicht geprüft: mit der echten Press-App auf einem Telefon (scannen, melden, Antwort lesen). Das Format entspricht dem allgemeinen Code, aber nur gegen die Module der Officer-App getestet.
- Bekannte Grenze: Dieselbe Quelle, die aus derselben App an zwei Recherchen schreibt, ist in der Redaktion als dieselbe App erkennbar.
